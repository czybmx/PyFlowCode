/**
 * 工作流状态管理 (Zustand)
 * ------------------------------------------------------------------
 * 维护:
 *  - nodes / edges          当前工作流的节点与连线
 *  - selectedNodeId         当前选中的节点 (属性面板使用)
 *  - canvasState            画布的平移/缩放
 *  - consoleOutput          控制台输出
 *  - nodeStatus             节点执行状态 (idle/running/ok/error)
 *  - 子图导航栈              (双击 DefineFunc 进入子画布)
 */

"use client";

import { create } from "zustand";
import { createNodeInstance, getNodeDef } from "@/lib/pyflow/registry";
import { runWorkflow } from "@/lib/pyflow/interpreter";
import type {
  PyValue,
  WorkflowEdge,
  WorkflowNode,
} from "@/lib/pyflow/types";

// ---------------------------------------------------------------------------
// 子图导航
// ---------------------------------------------------------------------------

/** 子图路径 — 从顶层到当前位置 */
export interface SubgraphPath {
  /** 路径上的节点 ID (顶层到当前) */
  nodeIds: string[];
  /** 路径上的节点 label (用于面包屑显示) */
  labels: string[];
}

// ---------------------------------------------------------------------------
// Store 定义
// ---------------------------------------------------------------------------

interface WorkflowState {
  // 工作流数据
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];

  // 选区
  selectedNodeId: string | null;
  selectedEdgeId: string | null;

  // 画布状态
  canvas: {
    pan: { x: number; y: number };
    zoom: number;
  };

  // 控制台输出
  consoleOutput: { type: "log" | "error" | "info"; message: string; timestamp: number }[];

  // 子图导航
  subgraphPath: SubgraphPath;

  // 工具
  isRunning: boolean;
  showCodeGen: boolean;
  generatedCode: string;

  // 操作
  addNode: (type: string, pos: { x: number; y: number }) => string | null;
  removeNode: (id: string) => void;
  moveNode: (id: string, pos: { x: number; y: number }) => void;
  updateNodeParam: (id: string, portId: string, value: PyValue) => void;
  updateNodeTitle: (id: string, title: string) => void;
  selectNode: (id: string | null) => void;
  selectEdge: (id: string | null) => void;

  addEdge: (from: string, fromPort: string, to: string, toPort: string) => boolean;
  removeEdge: (id: string) => void;
  removeEdgeByEndpoints: (from: string, fromPort: string, to: string, toPort: string) => void;

  setCanvas: (canvas: Partial<{ pan: { x: number; y: number }; zoom: number }>) => void;

  run: () => void;
  clearConsole: () => void;
  consoleLog: (type: "log" | "error" | "info", message: string) => void;

  // 子图导航
  enterSubgraph: (nodeId: string) => void;
  exitSubgraph: () => void;
  exitToRoot: () => void;
  navigateTo: (index: number) => void;

  // 文件
  loadDocument: (doc: { nodes: WorkflowNode[]; edges: WorkflowEdge[] }) => void;
  exportDocument: () => { format_version: 1; nodes: WorkflowNode[]; edges: WorkflowEdge[] };
  generateCode: () => void;
  setShowCodeGen: (show: boolean) => void;

  // 重置
  reset: () => void;

  // 工具方法
  getCurrentNodes: () => WorkflowNode[];
  getCurrentEdges: () => WorkflowEdge[];
}

// ---------------------------------------------------------------------------
// ID 生成器
// ---------------------------------------------------------------------------

let idCounter = 1;
function genId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${idCounter++}`;
}

// ---------------------------------------------------------------------------
// 子图访问工具
// ---------------------------------------------------------------------------

/**
 * 根据当前 subgraphPath 获取当前所在层级的 nodes/edges 容器
 * 返回:
 *   - container: 当前层级的 { nodes, edges } 引用 (可修改)
 *   - parent: 上一层级的容器 (用于退出子图)
 */
function getCurrentContainer(
  rootNodes: WorkflowNode[],
  path: SubgraphPath,
): { nodes: WorkflowNode[]; edges: WorkflowEdge[] } {
  if (path.nodeIds.length === 0) {
    return { nodes: rootNodes, edges: [] }; // edges 在 store 中单独维护
  }

  // 遍历路径找到当前节点
  let currentNodes = rootNodes;
  let currentNode: WorkflowNode | undefined;

  for (let i = 0; i < path.nodeIds.length; i++) {
    currentNode = currentNodes.find((n) => n.id === path.nodeIds[i]);
    if (!currentNode || !currentNode.subgraph) {
      return { nodes: rootNodes, edges: [] };
    }
    currentNodes = currentNode.subgraph.nodes;
  }

  if (currentNode?.subgraph) {
    return { nodes: currentNode.subgraph.nodes, edges: currentNode.subgraph.edges };
  }

  return { nodes: rootNodes, edges: [] };
}

// ---------------------------------------------------------------------------
// Store 实现
// ---------------------------------------------------------------------------

export const useWorkflowStore = create<WorkflowState>((set, get) => ({
  nodes: [],
  edges: [],

  selectedNodeId: null,
  selectedEdgeId: null,

  canvas: {
    pan: { x: 0, y: 0 },
    zoom: 1,
  },

  consoleOutput: [],
  subgraphPath: { nodeIds: [], labels: [] },

  isRunning: false,
  showCodeGen: false,
  generatedCode: "",

  // -------------------------------------------------------------------------
  // 节点操作
  // -------------------------------------------------------------------------

  addNode: (type, pos) => {
    const id = genId("n");
    const node = createNodeInstance(type, id, pos);
    if (!node) return null;

    // 如果是 DefineFunc, 初始化空子图
    if (type === "func_define") {
      node.subgraph = { nodes: [], edges: [] };
      node.title = "my_func";
    }

    set((state) => {
      const { nodes, edges, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return { nodes: [...nodes, node] };
      }
      // 添加到子图
      const newNodes = structuredClone(nodes) as WorkflowNode[];
      let current = newNodes;
      for (const pathId of subgraphPath.nodeIds) {
        const found = current.find((n) => n.id === pathId);
        if (found?.subgraph) current = found.subgraph.nodes;
      }
      current.push(node);
      return { nodes: newNodes };
    });

    return id;
  },

  removeNode: (id) => {
    set((state) => {
      const { nodes, edges, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          nodes: nodes.filter((n) => n.id !== id),
          edges: edges.filter((e) => e.from !== id && e.to !== id),
          selectedNodeId: state.selectedNodeId === id ? null : state.selectedNodeId,
        };
      }
      // 在子图中删除
      const newNodes = structuredClone(nodes) as WorkflowNode[];
      let currentNodes: WorkflowNode[] = newNodes;
      let currentEdges: WorkflowEdge[] = [];
      for (let i = 0; i < subgraphPath.nodeIds.length; i++) {
        const found = currentNodes.find((n) => n.id === subgraphPath.nodeIds[i]);
        if (found?.subgraph) {
          currentNodes = found.subgraph.nodes;
          currentEdges = found.subgraph.edges;
        }
      }
      const idx = currentNodes.findIndex((n) => n.id === id);
      if (idx >= 0) currentNodes.splice(idx, 1);
      // 删除相关连线
      for (let i = currentEdges.length - 1; i >= 0; i--) {
        if (currentEdges[i].from === id || currentEdges[i].to === id) {
          currentEdges.splice(i, 1);
        }
      }
      return {
        nodes: newNodes,
        selectedNodeId: state.selectedNodeId === id ? null : state.selectedNodeId,
      };
    });
  },

  moveNode: (id, pos) => {
    set((state) => {
      const { nodes, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          nodes: nodes.map((n) => (n.id === id ? { ...n, pos } : n)),
        };
      }
      const newNodes = structuredClone(nodes) as WorkflowNode[];
      let currentNodes: WorkflowNode[] = newNodes;
      for (const pathId of subgraphPath.nodeIds) {
        const found = currentNodes.find((n) => n.id === pathId);
        if (found?.subgraph) currentNodes = found.subgraph.nodes;
      }
      const target = currentNodes.find((n) => n.id === id);
      if (target) target.pos = pos;
      return { nodes: newNodes };
    });
  },

  updateNodeParam: (id, portId, value) => {
    set((state) => {
      const { nodes, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          nodes: nodes.map((n) =>
            n.id === id ? { ...n, params: { ...n.params, [portId]: value } } : n,
          ),
        };
      }
      const newNodes = structuredClone(nodes) as WorkflowNode[];
      let currentNodes: WorkflowNode[] = newNodes;
      for (const pathId of subgraphPath.nodeIds) {
        const found = currentNodes.find((n) => n.id === pathId);
        if (found?.subgraph) currentNodes = found.subgraph.nodes;
      }
      const target = currentNodes.find((n) => n.id === id);
      if (target) target.params[portId] = value;
      return { nodes: newNodes };
    });
  },

  updateNodeTitle: (id, title) => {
    set((state) => {
      const { nodes, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          nodes: nodes.map((n) => (n.id === id ? { ...n, title } : n)),
        };
      }
      const newNodes = structuredClone(nodes) as WorkflowNode[];
      let currentNodes: WorkflowNode[] = newNodes;
      for (const pathId of subgraphPath.nodeIds) {
        const found = currentNodes.find((n) => n.id === pathId);
        if (found?.subgraph) currentNodes = found.subgraph.nodes;
      }
      const target = currentNodes.find((n) => n.id === id);
      if (target) target.title = title;
      return { nodes: newNodes };
    });
  },

  selectNode: (id) => set({ selectedNodeId: id, selectedEdgeId: null }),
  selectEdge: (id) => set({ selectedEdgeId: id, selectedNodeId: null }),

  // -------------------------------------------------------------------------
  // 连线操作
  // -------------------------------------------------------------------------

  addEdge: (from, fromPort, to, toPort) => {
    const state = get();
    const { subgraphPath } = state;

    // 类型检查
    const fromNode = state.nodes.find((n) => n.id === from);
    const toNode = state.nodes.find((n) => n.id === to);
    if (!fromNode || !toNode) return false;

    const fromDef = getNodeDef(fromNode.type);
    const toDef = getNodeDef(toNode.type);
    if (!fromDef || !toDef) return false;

    const fromPortDef = fromDef.outputs.find((p) => p.id === fromPort);
    const toPortDef = toDef.inputs.find((p) => p.id === toPort);
    if (!fromPortDef || !toPortDef) return false;

    // 检查类型兼容
    // (类型检查逻辑放在 UI 层, 这里直接允许)

    // 检查目标端口是否已有连线 (非 multi 端口只允许一条)
    if (!toPortDef.multi) {
      // 删除已有的连线
      get().removeEdgeByEndpoints("*", "*", to, toPort);
    }

    const newEdge: WorkflowEdge = {
      id: genId("e"),
      from,
      fromPort,
      to,
      toPort,
    };

    set((s) => {
      if (subgraphPath.nodeIds.length === 0) {
        return { edges: [...s.edges, newEdge] };
      }
      // 添加到子图
      const newNodes = structuredClone(s.nodes) as WorkflowNode[];
      let currentNodes: WorkflowNode[] = newNodes;
      for (const pathId of subgraphPath.nodeIds) {
        const found = currentNodes.find((n) => n.id === pathId);
        if (found?.subgraph) currentNodes = found.subgraph.nodes;
      }
      // currentNodes 的父级 subgraph.edges 需要更新
      // 简化: 找到当前 subgraph 容器
      let container: WorkflowNode | null = null;
      let containerNodes = newNodes;
      for (let i = 0; i < subgraphPath.nodeIds.length; i++) {
        container = containerNodes.find((n) => n.id === subgraphPath.nodeIds[i]) ?? null;
        if (i < subgraphPath.nodeIds.length - 1) {
          containerNodes = container?.subgraph?.nodes ?? [];
        }
      }
      if (container?.subgraph) {
        container.subgraph.edges.push(newEdge);
      }
      return { nodes: newNodes };
    });

    return true;
  },

  removeEdge: (id) => {
    set((state) => {
      const { edges, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          edges: edges.filter((e) => e.id !== id),
          selectedEdgeId: state.selectedEdgeId === id ? null : state.selectedEdgeId,
        };
      }
      const newNodes = structuredClone(state.nodes) as WorkflowNode[];
      let container: WorkflowNode | null = null;
      let containerNodes = newNodes;
      for (let i = 0; i < subgraphPath.nodeIds.length; i++) {
        container = containerNodes.find((n) => n.id === subgraphPath.nodeIds[i]) ?? null;
        if (i < subgraphPath.nodeIds.length - 1) {
          containerNodes = container?.subgraph?.nodes ?? [];
        }
      }
      if (container?.subgraph) {
        container.subgraph.edges = container.subgraph.edges.filter((e) => e.id !== id);
      }
      return {
        nodes: newNodes,
        selectedEdgeId: state.selectedEdgeId === id ? null : state.selectedEdgeId,
      };
    });
  },

  removeEdgeByEndpoints: (from, fromPort, to, toPort) => {
    set((state) => {
      const { edges, subgraphPath } = state;
      if (subgraphPath.nodeIds.length === 0) {
        return {
          edges: edges.filter(
            (e) =>
              !(e.to === to && e.toPort === toPort &&
                (from === "*" || e.from === from) &&
                (fromPort === "*" || e.fromPort === fromPort)),
          ),
        };
      }
      const newNodes = structuredClone(state.nodes) as WorkflowNode[];
      let container: WorkflowNode | null = null;
      let containerNodes = newNodes;
      for (let i = 0; i < subgraphPath.nodeIds.length; i++) {
        container = containerNodes.find((n) => n.id === subgraphPath.nodeIds[i]) ?? null;
        if (i < subgraphPath.nodeIds.length - 1) {
          containerNodes = container?.subgraph?.nodes ?? [];
        }
      }
      if (container?.subgraph) {
        container.subgraph.edges = container.subgraph.edges.filter(
          (e) =>
            !(e.to === to && e.toPort === toPort &&
              (from === "*" || e.from === from) &&
              (fromPort === "*" || e.fromPort === fromPort)),
        );
      }
      return { nodes: newNodes };
    });
  },

  // -------------------------------------------------------------------------
  // 画布
  // -------------------------------------------------------------------------

  setCanvas: (canvas) =>
    set((state) => ({
      canvas: {
        pan: canvas.pan ?? state.canvas.pan,
        zoom: canvas.zoom ?? state.canvas.zoom,
      },
    })),

  // -------------------------------------------------------------------------
  // 运行
  // -------------------------------------------------------------------------

  run: () => {
    const state = get();
    if (state.isRunning) return;
    if (state.subgraphPath.nodeIds.length > 0) {
      // 子图不能直接运行
      state.consoleLog("error", "请在顶层画布运行工作流 (使用面包屑返回顶层)");
      return;
    }

    set({ isRunning: true });
    state.consoleLog("info", "▶ 开始执行工作流...");

    try {
      const result = runWorkflow(state.nodes, state.edges, {
        maxDepth: 50,
        maxIterations: 10000,
      });

      for (const line of result.console) {
        state.consoleLog("log", line);
      }

      if (result.errors.length > 0) {
        for (const err of result.errors) {
          const node = state.nodes.find((n) => n.id === err.nodeId);
          state.consoleLog("error", `节点 ${node?.title ?? err.nodeId}: ${err.message}`);
        }
      } else {
        state.consoleLog("info", `✓ 执行完成 (${result.executionOrder.length} 个节点)`);
      }
    } catch (e) {
      state.consoleLog("error", `运行时错误: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      set({ isRunning: false });
    }
  },

  clearConsole: () => set({ consoleOutput: [] }),

  consoleLog: (type, message) =>
    set((state) => ({
      consoleOutput: [
        ...state.consoleOutput.slice(-500), // 保留最近 500 条
        { type, message, timestamp: Date.now() },
      ],
    })),

  // -------------------------------------------------------------------------
  // 子图导航
  // -------------------------------------------------------------------------

  enterSubgraph: (nodeId) => {
    const state = get();
    const node = state.nodes.find((n) => n.id === nodeId);
    if (!node) return;
    const def = getNodeDef(node.type);
    if (!def?.isSubgraph) return;

    // 确保子图存在
    if (!node.subgraph) {
      node.subgraph = { nodes: [], edges: [] };
    }

    set({
      subgraphPath: {
        nodeIds: [...state.subgraphPath.nodeIds, nodeId],
        labels: [...state.subgraphPath.labels, node.title ?? def.label],
      },
      selectedNodeId: null,
    });
  },

  exitSubgraph: () => {
    const state = get();
    if (state.subgraphPath.nodeIds.length === 0) return;
    set({
      subgraphPath: {
        nodeIds: state.subgraphPath.nodeIds.slice(0, -1),
        labels: state.subgraphPath.labels.slice(0, -1),
      },
      selectedNodeId: null,
    });
  },

  exitToRoot: () =>
    set({ subgraphPath: { nodeIds: [], labels: [] }, selectedNodeId: null }),

  navigateTo: (index) => {
    const state = get();
    if (index < 0 || index >= state.subgraphPath.nodeIds.length) {
      set({ subgraphPath: { nodeIds: [], labels: [] } });
      return;
    }
    set({
      subgraphPath: {
        nodeIds: state.subgraphPath.nodeIds.slice(0, index + 1),
        labels: state.subgraphPath.labels.slice(0, index + 1),
      },
      selectedNodeId: null,
    });
  },

  // -------------------------------------------------------------------------
  // 文件
  // -------------------------------------------------------------------------

  loadDocument: (doc) => {
    set({
      nodes: doc.nodes,
      edges: doc.edges,
      selectedNodeId: null,
      selectedEdgeId: null,
      subgraphPath: { nodeIds: [], labels: [] },
      consoleOutput: [],
    });
  },

  exportDocument: () => {
    const state = get();
    return {
      format_version: 1 as const,
      nodes: state.nodes,
      edges: state.edges,
    };
  },

  generateCode: () => {
    const state = get();
    // 动态导入避免循环依赖
    import("@/lib/pyflow/codegen").then(({ generatePython }) => {
      const code = generatePython(state.nodes, state.edges);
      set({ generatedCode: code, showCodeGen: true });
    });
  },

  setShowCodeGen: (show) => set({ showCodeGen: show }),

  reset: () =>
    set({
      nodes: [],
      edges: [],
      selectedNodeId: null,
      selectedEdgeId: null,
      consoleOutput: [],
      subgraphPath: { nodeIds: [], labels: [] },
    }),

  // -------------------------------------------------------------------------
  // 工具
  // -------------------------------------------------------------------------

  getCurrentNodes: () => {
    const state = get();
    if (state.subgraphPath.nodeIds.length === 0) return state.nodes;

    let current = state.nodes;
    for (const pathId of state.subgraphPath.nodeIds) {
      const found = current.find((n) => n.id === pathId);
      if (found?.subgraph) current = found.subgraph.nodes;
      else return [];
    }
    return current;
  },

  getCurrentEdges: () => {
    const state = get();
    if (state.subgraphPath.nodeIds.length === 0) return state.edges;

    let current = state.nodes;
    let edges: WorkflowEdge[] = [];
    for (const pathId of state.subgraphPath.nodeIds) {
      const found = current.find((n) => n.id === pathId);
      if (found?.subgraph) {
        current = found.subgraph.nodes;
        edges = found.subgraph.edges;
      } else return [];
    }
    return edges;
  },
}));
