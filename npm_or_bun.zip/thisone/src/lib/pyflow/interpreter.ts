/**
 * PyFlowCode 解释器
 * ------------------------------------------------------------------
 * 将节点图作为有向无环图 (DAG) 执行:
 *  1. 拓扑排序节点 (按依赖顺序)
 *  2. 依次执行每个节点, 解析输入端口值
 *     - 若端口有连线, 取源节点的输出缓存
 *     - 若端口无连线, 取节点参数或端口默认值
 *  3. 缓存输出, 供后续节点使用
 *  4. 特殊节点 (literal_*, func_define, func_call, control_filter, control_map)
 *     由解释器特殊处理
 *
 * 支持控制流:
 *  - control_if:     根据条件选择输出
 *  - control_for_each: 输出 list, 不引入循环
 *  - func_define/call: 通过闭包支持函数定义和调用
 *  - filter/map:     通过 callable 对列表进行操作
 */

import { getNodeDef } from "./registry";
import { pyStr } from "./builtin-nodes";
import type {
  ExecutionContext,
  PyValue,
  WorkflowEdge,
  WorkflowNode,
} from "./types";

// ---------------------------------------------------------------------------
// 拓扑排序
// ---------------------------------------------------------------------------

/** 对节点进行拓扑排序 (Kahn 算法) */
function topologicalSort(nodes: WorkflowNode[], edges: WorkflowEdge[]): WorkflowNode[] {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const inDegree = new Map<string, number>();
  const outEdges = new Map<string, string[]>();

  for (const node of nodes) {
    inDegree.set(node.id, 0);
    outEdges.set(node.id, []);
  }

  for (const edge of edges) {
    if (!nodeMap.has(edge.from) || !nodeMap.has(edge.to)) continue;
    inDegree.set(edge.to, (inDegree.get(edge.to) ?? 0) + 1);
    outEdges.get(edge.from)?.push(edge.to);
  }

  const queue: string[] = [];
  for (const [id, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(id);
  }

  const sorted: WorkflowNode[] = [];
  while (queue.length > 0) {
    const id = queue.shift()!;
    const node = nodeMap.get(id);
    if (node) sorted.push(node);

    for (const next of outEdges.get(id) ?? []) {
      const newDeg = (inDegree.get(next) ?? 1) - 1;
      inDegree.set(next, newDeg);
      if (newDeg === 0) queue.push(next);
    }
  }

  // 检测循环依赖
  if (sorted.length !== nodes.length) {
    // 把剩余节点也加进去 (执行时会报错)
    for (const node of nodes) {
      if (!sorted.find((n) => n.id === node.id)) sorted.push(node);
    }
  }

  return sorted;
}

// ---------------------------------------------------------------------------
// 解释器
// ---------------------------------------------------------------------------

export interface InterpreterResult {
  /** 每个节点的输出 */
  outputs: Map<string, Record<string, PyValue>>;
  /** 控制台输出 (Print 节点产生) */
  console: string[];
  /** 执行中遇到的错误 */
  errors: { nodeId: string; message: string }[];
  /** 执行顺序 (用于 UI 高亮) */
  executionOrder: string[];
}

export interface InterpreterOptions {
  /** 最大调用深度 (防止无限递归) */
  maxDepth?: number;
  /** 最大迭代次数 (防止无限循环) */
  maxIterations?: number;
}

export function runWorkflow(
  nodes: WorkflowNode[],
  edges: WorkflowEdge[],
  options: InterpreterOptions = {},
): InterpreterResult {
  const result: InterpreterResult = {
    outputs: new Map(),
    console: [],
    errors: [],
    executionOrder: [],
  };

  const maxDepth = options.maxDepth ?? 100;
  const maxIterations = options.maxIterations ?? 10000;

  const sortedNodes = topologicalSort(nodes, edges);

  const baseCtx: ExecutionContext = {
    nodes,
    edges,
    log: (msg) => result.console.push(pyStr(msg)),
    scope: {},
    depth: 0,
  };

  for (const node of sortedNodes) {
    result.executionOrder.push(node.id);
    try {
      const outputs = executeNode(node, baseCtx, result.outputs, edges, maxDepth, maxIterations, new Set());
      result.outputs.set(node.id, outputs);
      // 更新节点的运行时状态
      node._runtime = { outputs, status: "ok" };
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      result.errors.push({ nodeId: node.id, message });
      result.outputs.set(node.id, {});
      node._runtime = { error: message, status: "error" };
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// 单节点执行
// ---------------------------------------------------------------------------

function executeNode(
  node: WorkflowNode,
  ctx: ExecutionContext,
  outputs: Map<string, Record<string, PyValue>>,
  edges: WorkflowEdge[],
  maxDepth: number,
  maxIterations: number,
  callStack: Set<string>,
): Record<string, PyValue> {
  const def = getNodeDef(node.type);
  if (!def) {
    throw new Error(`未知的节点类型: ${node.type}`);
  }

  // 解析输入端口值
  const inputs: Record<string, PyValue> = {};
  for (const port of def.inputs) {
    const incomingEdge = edges.find((e) => e.to === node.id && e.toPort === port.id);
    if (incomingEdge) {
      const sourceOutputs = outputs.get(incomingEdge.from);
      if (sourceOutputs && incomingEdge.fromPort in sourceOutputs) {
        inputs[port.id] = sourceOutputs[incomingEdge.fromPort];
      } else {
        inputs[port.id] = port.default ?? null;
      }
    } else {
      // 无连线: 使用节点参数或默认值
      if (node.params[port.id] !== undefined) {
        inputs[port.id] = node.params[port.id];
      } else {
        inputs[port.id] = port.default ?? null;
      }
    }
  }

  // 特殊节点处理
  switch (node.type) {
    case "literal_int":
    case "literal_float":
    case "literal_str":
    case "literal_bool":
      return { value: node.params.value ?? null };

    case "func_define":
      return executeDefineFunc(node, ctx, outputs, edges, maxDepth, maxIterations);

    case "func_call":
      return executeCall(node, inputs, ctx, outputs, edges, maxDepth, maxIterations, callStack);

    case "control_filter":
      return executeFilter(node, inputs, ctx, outputs, edges, maxDepth, maxIterations, callStack);

    case "control_map":
      return executeMap(node, inputs, ctx, outputs, edges, maxDepth, maxIterations, callStack);

    case "func_return":
      // Return 节点本身不产生输出, 它的输入值会被 DefineFunc 的子图执行器使用
      return { value: inputs.value };

    default:
      // 通用执行
      return def.execute({ ...ctx, depth: ctx.depth + 1 }, inputs);
  }
}

// ---------------------------------------------------------------------------
// DefineFunc 执行 — 创建闭包
// ---------------------------------------------------------------------------

function executeDefineFunc(
  node: WorkflowNode,
  ctx: ExecutionContext,
  _outputs: Map<string, Record<string, PyValue>>,
  _edges: WorkflowEdge[],
  _maxDepth: number,
  _maxIterations: number,
): Record<string, PyValue> {
  if (!node.subgraph || !node.subgraph.nodes.length) {
    // 无函数体, 返回空函数
    return {
      func: {
        __py_type: "callable",
        name: node.title ?? "anonymous",
        closure: {
          params: ["param0", "param1"],
          bodyNodeIds: [],
          returnSource: { nodeId: "", portId: "" },
          capturedScope: { ...ctx.scope },
        },
      },
    };
  }

  const def = getNodeDef(node.type)!;
  const params = def.inputs.map((p) => p.id);

  // 查找 Return 节点作为返回值来源
  const returnNode = node.subgraph.nodes.find((n) => n.type === "func_return");
  const returnSource = returnNode
    ? { nodeId: returnNode.id, portId: "value" }
    : { nodeId: node.subgraph.nodes[node.subgraph.nodes.length - 1].id, portId: "value" };

  return {
    func: {
      __py_type: "callable",
      name: node.title ?? "anonymous",
      closure: {
        params,
        bodyNodeIds: node.subgraph.nodes.map((n) => n.id),
        returnSource,
        capturedScope: { ...ctx.scope },
      },
    },
  };
}

// ---------------------------------------------------------------------------
// Call 执行 — 调用闭包
// ---------------------------------------------------------------------------

function executeCall(
  node: WorkflowNode,
  inputs: Record<string, PyValue>,
  ctx: ExecutionContext,
  _outputs: Map<string, Record<string, PyValue>>,
  _edges: WorkflowEdge[],
  maxDepth: number,
  maxIterations: number,
  callStack: Set<string>,
): Record<string, PyValue> {
  const func = inputs.func;
  if (!func || typeof func !== "object" || func.__py_type !== "callable") {
    throw new Error("Call 节点的 func 输入不是可调用对象");
  }

  if (ctx.depth >= maxDepth) {
    throw new Error(`达到最大调用深度 ${maxDepth}, 可能存在无限递归`);
  }

  if (callStack.has(node.id)) {
    throw new Error(`检测到递归调用循环 (节点 ${node.id})`);
  }

  // 查找 DefineFunc 节点 (子图来源)
  const defineNode = ctx.nodes.find((n) => n.type === "func_define" && n.title === func.name);
  // 如果找不到, 也可以从 closure 找
  if (!defineNode || !defineNode.subgraph) {
    // 没有子图, 返回 None
    return { return: null };
  }

  // 在子图中执行
  const subNodes = defineNode.subgraph.nodes;
  const subEdges = defineNode.subgraph.edges;

  // 将参数注入对应端口 (param0, param1, ...)
  const subOutputs = new Map<string, Record<string, PyValue>>();
  for (const paramId of func.closure.params) {
    // 找到接收该参数的节点 (通常是 Literal/Pass-through 节点, 或者直接是后续节点)
    // 简化: 找到子图中所有以 paramId 为输入端口的连线, 替换为参数值
  }

  // 创建参数值映射
  const paramValues: Record<string, PyValue> = {};
  func.closure.params.forEach((p, i) => {
    paramValues[p] = inputs[`arg${i}`] ?? null;
  });

  // 拓扑排序子图
  const sorted = topologicalSort(subNodes, subEdges);

  // 执行子图
  const subCtx: ExecutionContext = {
    ...ctx,
    nodes: subNodes,
    edges: subEdges,
    scope: { ...func.closure.capturedScope, ...paramValues },
    depth: ctx.depth + 1,
  };

  // 把参数值预先放到对应的"参数端口"作为输入
  // 子图中: 我们需要一个机制让参数值流入子图节点
  // 简化: 在子图中创建虚拟的 param 节点
  // 但更简单的方式: 修改子图的 edges, 让指向 param0/param1 的边从虚拟源获取
  // 我们直接在执行时拦截: 如果某个节点的输入端口是 param0/param1 且没有连线, 使用参数值

  // 实际上更优雅的方式是子图中有一个特殊的 Param 节点
  // 这里我们采用: 子图节点如果输入端口没连线, 且 portId 在 paramValues 中, 用 paramValues

  const newCallStack = new Set(callStack);
  newCallStack.add(node.id);

  let returnValue: PyValue = null;

  for (const subNode of sorted) {
    try {
      const subDef = getNodeDef(subNode.type);
      if (!subDef) continue;

      const subInputs: Record<string, PyValue> = {};
      for (const port of subDef.inputs) {
        const incomingEdge = subEdges.find((e) => e.to === subNode.id && e.toPort === port.id);
        if (incomingEdge) {
          const sourceOutputs = subOutputs.get(incomingEdge.from);
          subInputs[port.id] = sourceOutputs?.[incomingEdge.fromPort] ?? port.default ?? null;
        } else if (subNode.params[port.id] !== undefined) {
          subInputs[port.id] = subNode.params[port.id];
        } else if (paramValues[port.id] !== undefined) {
          subInputs[port.id] = paramValues[port.id];
        } else {
          subInputs[port.id] = port.default ?? null;
        }
      }

      // 特殊处理子图中的 Return 节点
      if (subNode.type === "func_return") {
        returnValue = subInputs.value;
        subOutputs.set(subNode.id, { value: subInputs.value });
        continue;
      }

      // 字面量
      if (
        subNode.type === "literal_int" ||
        subNode.type === "literal_float" ||
        subNode.type === "literal_str" ||
        subNode.type === "literal_bool"
      ) {
        subOutputs.set(subNode.id, { value: subNode.params.value ?? null });
        continue;
      }

      // Call 嵌套
      if (subNode.type === "func_call") {
        const r = executeCall(subNode, subInputs, subCtx, subOutputs, subEdges, maxDepth, maxIterations, newCallStack);
        subOutputs.set(subNode.id, r);
        continue;
      }

      // Filter / Map 嵌套
      if (subNode.type === "control_filter") {
        const r = executeFilter(subNode, subInputs, subCtx, subOutputs, subEdges, maxDepth, maxIterations, newCallStack);
        subOutputs.set(subNode.id, r);
        continue;
      }
      if (subNode.type === "control_map") {
        const r = executeMap(subNode, subInputs, subCtx, subOutputs, subEdges, maxDepth, maxIterations, newCallStack);
        subOutputs.set(subNode.id, r);
        continue;
      }

      const outputs = subDef.execute(subCtx, subInputs);
      subOutputs.set(subNode.id, outputs);

      // 如果是 Return 节点, 记录返回值
      if (subNode.type === "func_return") {
        returnValue = subInputs.value;
      }
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      throw new Error(`函数 ${func.name} 内节点 ${subNode.id} 执行失败: ${message}`);
    }

    if (ctx.depth > maxIterations) {
      throw new Error("达到最大迭代次数");
    }
  }

  return { return: returnValue };
}

// ---------------------------------------------------------------------------
// Filter / Map 执行
// ---------------------------------------------------------------------------

function executeFilter(
  node: WorkflowNode,
  inputs: Record<string, PyValue>,
  ctx: ExecutionContext,
  outputs: Map<string, Record<string, PyValue>>,
  edges: WorkflowEdge[],
  maxDepth: number,
  maxIterations: number,
  callStack: Set<string>,
): Record<string, PyValue> {
  const iterable = inputs.iterable;
  const func = inputs.func;
  let arr: PyValue[] = [];
  if (Array.isArray(iterable)) arr = iterable;
  else if (typeof iterable === "string") arr = iterable.split("");

  if (!func || typeof func !== "object" || func.__py_type !== "callable") {
    return { result: arr };
  }

  // 对每个元素调用 callable
  const result: PyValue[] = [];
  let iter = 0;
  for (const item of arr) {
    if (iter++ > maxIterations) throw new Error("Filter 达到最大迭代次数");
    // 模拟调用: 把 item 作为 arg0
    const callInputs = { ...inputs, func, arg0: item, arg1: null };
    const callResult = executeCall(
      node, // 复用节点 id (其实应该用一个新的, 但递归保护需要)
      callInputs,
      ctx,
      outputs,
      edges,
      maxDepth,
      maxIterations,
      new Set(callStack),
    );
    if (callResult.return) {
      result.push(item);
    }
  }
  return { result };
}

function executeMap(
  node: WorkflowNode,
  inputs: Record<string, PyValue>,
  ctx: ExecutionContext,
  outputs: Map<string, Record<string, PyValue>>,
  edges: WorkflowEdge[],
  maxDepth: number,
  maxIterations: number,
  callStack: Set<string>,
): Record<string, PyValue> {
  const iterable = inputs.iterable;
  const func = inputs.func;
  let arr: PyValue[] = [];
  if (Array.isArray(iterable)) arr = iterable;
  else if (typeof iterable === "string") arr = iterable.split("");

  if (!func || typeof func !== "object" || func.__py_type !== "callable") {
    return { result: arr };
  }

  const result: PyValue[] = [];
  let iter = 0;
  for (const item of arr) {
    if (iter++ > maxIterations) throw new Error("Map 达到最大迭代次数");
    const callInputs = { ...inputs, func, arg0: item, arg1: null };
    const callResult = executeCall(
      node,
      callInputs,
      ctx,
      outputs,
      edges,
      maxDepth,
      maxIterations,
      new Set(callStack),
    );
    result.push(callResult.return);
  }
  return { result };
}
