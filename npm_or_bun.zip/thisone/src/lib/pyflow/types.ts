/**
 * PyFlowCode 核心类型定义
 * ------------------------------------------------------------------
 * 设计目标：在浏览器中以节点图的形式表达 Python 程序。
 *  - 节点 (Node)        对应 Python 中的一个值/运算/控制结构
 *  - 端口 (Port)        对应函数的输入/输出参数，携带 Python 类型
 *  - 连线 (Edge)        数据从输出端口流向输入端口
 *  - 工作流 (Workflow)  完整的图，可解释执行，也可反向生成 .py
 */

// ---------------------------------------------------------------------------
// Python 类型系统（前端表示）
// ---------------------------------------------------------------------------

/** 基础 Python 类型枚举 — 用于颜色与类型兼容性判定 */
export type PyType =
  | "int"
  | "float"
  | "bool"
  | "str"
  | "bytes"
  | "list"
  | "dict"
  | "tuple"
  | "set"
  | "range"
  | "callable"
  | "module"
  | "none"
  | "any";

/** 端口方向 */
export type PortDirection = "input" | "output";

/** 端口定义 */
export interface PortDef {
  /** 端口标识 (在节点内唯一) */
  id: string;
  /** 显示名称 */
  label: string;
  /** Python 类型 */
  type: PyType;
  /** 是否允许多个连线接入 (输入端口才有效) */
  multi?: boolean;
  /** 默认值 (输入端口若无连线，使用此值) */
  default?: PyValue;
  /** 是否可在属性面板编辑默认值 */
  editable?: boolean;
  /** 字面量节点的可选值类型列表 (仅 Literal 节点用) */
  enumValues?: { label: string; value: PyValue }[];
}

// ---------------------------------------------------------------------------
// 运行时 Python 值 (JS 表示)
// ---------------------------------------------------------------------------

/** Python 运行时值的 JS 表示 */
export type PyValue =
  | number
  | string
  | boolean
  | null
  | PyValue[]
  | { __py_type: "dict"; entries: [PyValue, PyValue][] }
  | { __py_type: "tuple"; items: PyValue[] }
  | { __py_type: "set"; items: PyValue[] }
  | { __py_type: "range"; start: number; stop: number; step: number }
  | { __py_type: "callable"; name: string; closure: PyClosure }
  | { __py_type: "module"; name: string };

/** 函数闭包 — 由 DefineFunc 节点产生 */
export interface PyClosure {
  /** 参数名列表 (与 DefineFunc 节点的输入端口一一对应) */
  params: string[];
  /** 函数体子图节点 ID 列表 (按执行顺序) */
  bodyNodeIds: string[];
  /** 返回值来源端口 (DefineFunc 节点子图的出口) */
  returnSource: { nodeId: string; portId: string };
  /** 闭包捕获的外层作用域变量 */
  capturedScope?: Record<string, PyValue>;
}

// ---------------------------------------------------------------------------
// 节点定义与运行时
// ---------------------------------------------------------------------------

/** 节点分类 (用于左侧节点面板分组) */
export type NodeCategory =
  | "literal"
  | "operator"
  | "comparison"
  | "logic"
  | "container"
  | "string"
  | "control"
  | "function"
  | "io"
  | "module";

/** 节点类型定义 (注册表中的静态描述) */
export interface NodeTypeDef {
  /** 节点类型唯一标识 */
  type: string;
  /** 显示名称 */
  label: string;
  /** 分类 */
  category: NodeCategory;
  /** 输入端口定义 */
  inputs: PortDef[];
  /** 输出端口定义 */
  outputs: PortDef[];
  /** 是否为子图节点 (双击进入子画布) */
  isSubgraph?: boolean;
  /** 是否为控制流节点 (执行时产生分支/迭代) */
  isControlFlow?: boolean;
  /** 节点描述 */
  description?: string;
  /** 节点默认尺寸提示 */
  defaultSize?: { width: number; height: number };
  /**
   * 执行函数 — 接收输入值与上下文，返回输出端口 -> 值映射
   */
  execute: (ctx: ExecutionContext, inputs: Record<string, PyValue>) => Record<string, PyValue>;
  /**
   * 代码生成函数 — 返回该节点对应的 Python 代码片段
   */
  toCode?: (ctx: CodeGenContext, inputs: Record<string, string>) => CodeGenResult;
}

/** 节点执行上下文 */
export interface ExecutionContext {
  /** 当前工作流中的所有节点 (含子图节点) */
  nodes: WorkflowNode[];
  /** 当前工作流中的所有连线 */
  edges: WorkflowEdge[];
  /** 输出日志 (用于 Print 节点) */
  log: (msg: PyValue) => void;
  /** 设置断点处的值 (用于断点调试 UI) */
  setBreakpointValue?: (edgeId: string, value: PyValue) => void;
  /** 当前作用域变量 (变量节点使用) */
  scope: Record<string, PyValue>;
  /** 调用栈深度 (用于防止无限递归) */
  depth: number;
}

/** 代码生成上下文 */
export interface CodeGenContext {
  /** 已生成的语句列表 (按顺序) */
  statements: string[];
  /** 当前作用域中已使用的变量名 (用于避免命名冲突) */
  usedNames: Set<string>;
  /** 当前缩进级别 */
  indent: number;
}

/** 代码生成结果 */
export interface CodeGenResult {
  /** 输出端口 -> Python 表达式字符串 */
  assignments: Record<string, string>;
  /** 额外要追加的语句 (如 print、if 块) */
  statements?: string[];
  /** 是否需要展开为多行块 (if/for/def) */
  block?: {
    /** 块头 (如 "if cond:" / "for item in iter:") */
    header: string;
    /** 块内代码生成回调 — 在子作用域内生成 */
    body: (innerCtx: CodeGenContext) => void;
  };
}

// ---------------------------------------------------------------------------
// 工作流 (运行时图结构)
// ---------------------------------------------------------------------------

/** 工作流中的节点实例 */
export interface WorkflowNode {
  /** 实例唯一 ID */
  id: string;
  /** 节点类型 (对应 NodeTypeDef.type) */
  type: string;
  /** 画布坐标 */
  pos: { x: number; y: number };
  /** 节点实例自定义标签 (可选, 显示在节点顶部) */
  title?: string;
  /** 参数覆盖 (覆盖节点默认值, key = portId) */
  params: Record<string, PyValue>;
  /** 子图内容 (仅子图节点有效) */
  subgraph?: {
    nodes: WorkflowNode[];
    edges: WorkflowEdge[];
  };
  /** 运行时输出缓存 (执行后填充) */
  _runtime?: {
    outputs?: Record<string, PyValue>;
    error?: string;
    status?: "idle" | "running" | "ok" | "error";
  };
}

/** 工作流中的连线 */
export interface WorkflowEdge {
  /** 连线唯一 ID */
  id: string;
  /** 源节点 ID */
  from: string;
  /** 源端口 ID */
  fromPort: string;
  /** 目标节点 ID */
  to: string;
  /** 目标端口 ID */
  toPort: string;
}

/** 完整工作流 (.pyflow 文件内容) */
export interface PyFlowDocument {
  format_version: 1;
  name?: string;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
}

// ---------------------------------------------------------------------------
// 类型工具
// ---------------------------------------------------------------------------

/** 检查 from 类型是否可连接到 to 类型 */
export function isTypeCompatible(from: PyType, to: PyType): boolean {
  if (from === "any" || to === "any") return true;
  if (from === to) return true;
  // int 兼容 float (Python 自动转换)
  if (from === "int" && to === "float") return true;
  // bool 兼容 int (Python 中 bool 是 int 子类)
  if (from === "bool" && (to === "int" || to === "float")) return true;
  // int 兼容 bool (语义上)
  if (from === "int" && to === "bool") return true;
  return false;
}

/** 获取类型对应的颜色 (用于端口圆点) */
export function getTypeColor(type: PyType): string {
  const colors: Record<PyType, string> = {
    int: "#3b82f6",
    float: "#06b6d4",
    bool: "#a855f7",
    str: "#22c55e",
    bytes: "#65a30d",
    list: "#f59e0b",
    dict: "#ef4444",
    tuple: "#f97316",
    set: "#eab308",
    range: "#14b8a6",
    callable: "#ec4899",
    module: "#64748b",
    none: "#94a3b8",
    any: "#ffffff",
  };
  return colors[type] ?? "#94a3b8";
}

/** 类型中文显示名 */
export function getTypeLabel(type: PyType): string {
  const labels: Record<PyType, string> = {
    int: "int",
    float: "float",
    bool: "bool",
    str: "str",
    bytes: "bytes",
    list: "list",
    dict: "dict",
    tuple: "tuple",
    set: "set",
    range: "range",
    callable: "callable",
    module: "module",
    none: "None",
    any: "Any",
  };
  return labels[type];
}
