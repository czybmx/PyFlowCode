/**
 * PyFlowCode 内置节点库
 * ------------------------------------------------------------------
 * 每个节点定义包含:
 *  - inputs/outputs: 端口定义 (类型、默认值、是否可编辑)
 *  - execute():      解释执行时的逻辑
 *  - toCode():       Python 代码生成
 *
 * 节点按分类组织:
 *  - literal    : 字面量 (int/float/str/bool/None)
 *  - operator   : 算术 (+, -, *, /, %, **, //)
 *  - comparison : 比较 (==, !=, >, <, >=, <=)
 *  - logic      : 逻辑 (and, or, not)
 *  - container  : 容器 (list/dict/range/length/index/append)
 *  - string     : 字符串 (format/concat)
 *  - control    : 控制流 (if/forEach)
 *  - function   : 函数 (define/call/return)
 *  - io         : 输入输出 (print)
 *  - module     : 模块 (import)
 */

import { registerNode } from "./registry";
import type { CodeGenResult, NodeTypeDef, PyValue } from "./types";

// ---------------------------------------------------------------------------
// 辅助函数
// ---------------------------------------------------------------------------

/** 将 PyValue 转换为 Python 字面量字符串 (代码生成用) */
function pyRepr(v: PyValue): string {
  if (v === null) return "None";
  if (typeof v === "boolean") return v ? "True" : "False";
  if (typeof v === "number") return String(v);
  if (typeof v === "string") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(pyRepr).join(", ") + "]";
  if (typeof v === "object") {
    if (v.__py_type === "dict") {
      return "{" + v.entries.map(([k, val]) => `${pyRepr(k)}: ${pyRepr(val)}`).join(", ") + "}";
    }
    if (v.__py_type === "tuple") return "(" + v.items.map(pyRepr).join(", ") + ")";
    if (v.__py_type === "set") return "{" + v.items.map(pyRepr).join(", ") + "}";
    if (v.__py_type === "range") return `range(${v.start}, ${v.stop}, ${v.step})`;
    if (v.__py_type === "callable") return `<function ${v.name}>`;
    if (v.__py_type === "module") return `<module ${v.name}>`;
  }
  return "None";
}

/** 将 PyValue 转为可读字符串 (Print 节点用) */
function pyStr(v: PyValue): string {
  if (v === null) return "None";
  if (typeof v === "boolean") return v ? "True" : "False";
  if (typeof v === "number") return String(v);
  if (typeof v === "string") return v;
  if (Array.isArray(v)) return "[" + v.map(pyRepr).join(", ") + "]";
  if (typeof v === "object") {
    if (v.__py_type === "dict") {
      return "{" + v.entries.map(([k, val]) => `${pyRepr(k)}: ${pyRepr(val)}`).join(", ") + "}";
    }
    if (v.__py_type === "tuple") return "(" + v.items.map(pyRepr).join(", ") + ")";
    if (v.__py_type === "set") return "{" + v.items.map(pyRepr).join(", ") + "}";
    if (v.__py_type === "range") return `range(${v.start}, ${v.stop}, ${v.step})`;
    if (v.__py_type === "callable") return `<function ${v.name}>`;
    if (v.__py_type === "module") return `<module '${v.name}'>`;
  }
  return "None";
}

/** 获取参数值 (优先 params, 其次默认值) */
function getParam(node: { params: Record<string, PyValue> }, def: { inputs: { id: string; default?: PyValue }[] }, portId: string, inputs: Record<string, PyValue>): PyValue {
  if (inputs[portId] !== undefined) return inputs[portId];
  if (node.params[portId] !== undefined) return node.params[portId];
  const port = def.inputs.find((p) => p.id === portId);
  return port?.default ?? null;
}

// ---------------------------------------------------------------------------
// 1. 字面量节点
// 字面量节点的 execute / toCode 由解释器/代码生成器特殊处理 (使用 node.params.value)
// ---------------------------------------------------------------------------

registerNode({
  type: "literal_int",
  label: "整数",
  category: "literal",
  description: "一个整数字面量",
  inputs: [],
  outputs: [{ id: "value", label: "值", type: "int" }],
  defaultSize: { width: 160, height: 80 },
  execute: () => ({}),
  toCode: () => ({}),
});

registerNode({
  type: "literal_float",
  label: "浮点数",
  category: "literal",
  description: "一个浮点数字面量",
  inputs: [],
  outputs: [{ id: "value", label: "值", type: "float" }],
  defaultSize: { width: 160, height: 80 },
  execute: () => ({}),
  toCode: () => ({}),
});

registerNode({
  type: "literal_str",
  label: "字符串",
  category: "literal",
  description: "一个字符串字面量",
  inputs: [],
  outputs: [{ id: "value", label: "值", type: "str" }],
  defaultSize: { width: 200, height: 100 },
  execute: () => ({}),
  toCode: () => ({}),
});

registerNode({
  type: "literal_bool",
  label: "布尔值",
  category: "literal",
  description: "True 或 False",
  inputs: [],
  outputs: [{ id: "value", label: "值", type: "bool" }],
  defaultSize: { width: 160, height: 80 },
  execute: () => ({}),
  toCode: () => ({}),
});

registerNode({
  type: "literal_none",
  label: "None",
  category: "literal",
  description: "Python 的 None",
  inputs: [],
  outputs: [{ id: "value", label: "值", type: "none" }],
  defaultSize: { width: 120, height: 60 },
  execute: () => ({ value: null }),
  toCode: () => ({ assignments: { value: "None" } }),
});

// ---------------------------------------------------------------------------
// 2. 算术运算节点
// ---------------------------------------------------------------------------

function makeBinaryOp(
  type: string,
  label: string,
  opStr: string,
  op: (a: PyValue, b: PyValue) => PyValue,
  resultType: "int" | "float" | "any" = "any",
): NodeTypeDef {
  return {
    type,
    label,
    category: "operator",
    description: `${label} 运算`,
    inputs: [
      { id: "a", label: "a", type: "any", default: 0 },
      { id: "b", label: "b", type: "any", default: 0 },
    ],
    outputs: [{ id: "result", label: "结果", type: resultType }],
    defaultSize: { width: 140, height: 100 },
    execute: (_ctx, inputs) => {
      const a = inputs.a;
      const b = inputs.b;
      return { result: op(a, b) };
    },
    toCode: (_ctx, inputs) => ({
      assignments: { result: `(${inputs.a} ${opStr} ${inputs.b})` },
    }),
  };
}

registerNode(makeBinaryOp("op_add", "加法 (a + b)", "+", (a, b) => {
  if (typeof a === "string" || typeof b === "string") return pyStr(a) + pyStr(b);
  if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
  return (a as number) + (b as number);
}));

registerNode(makeBinaryOp("op_sub", "减法 (a - b)", "-", (a, b) => (a as number) - (b as number)));

registerNode(makeBinaryOp("op_mul", "乘法 (a * b)", "*", (a, b) => {
  if (typeof a === "string" && typeof b === "number") return a.repeat(b);
  if (typeof b === "string" && typeof a === "number") return b.repeat(a);
  if (Array.isArray(a) && typeof b === "number") return Array(b).fill(a).flat();
  return (a as number) * (b as number);
}));

registerNode(makeBinaryOp("op_div", "除法 (a / b)", "/", (a, b) => (a as number) / (b as number), "float"));

registerNode(makeBinaryOp("op_floordiv", "整除 (a // b)", "//", (a, b) => Math.floor((a as number) / (b as number))));

registerNode(makeBinaryOp("op_mod", "取余 (a % b)", "%", (a, b) => (a as number) % (b as number)));

registerNode(makeBinaryOp("op_pow", "幂 (a ** b)", "**", (a, b) => Math.pow(a as number, b as number)));

registerNode({
  type: "op_neg",
  label: "负号 (-a)",
  category: "operator",
  inputs: [{ id: "a", label: "a", type: "any", default: 0 }],
  outputs: [{ id: "result", label: "结果", type: "any" }],
  defaultSize: { width: 120, height: 80 },
  execute: (_ctx, inputs) => ({ result: -(inputs.a as number) }),
  toCode: (_ctx, inputs) => ({ assignments: { result: `(-${inputs.a})` } }),
});

// ---------------------------------------------------------------------------
// 3. 比较节点
// ---------------------------------------------------------------------------

function makeComparison(
  type: string,
  label: string,
  opStr: string,
  op: (a: PyValue, b: PyValue) => boolean,
): NodeTypeDef {
  return {
    type,
    label,
    category: "comparison",
    inputs: [
      { id: "a", label: "a", type: "any", default: 0 },
      { id: "b", label: "b", type: "any", default: 0 },
    ],
    outputs: [{ id: "result", label: "结果", type: "bool" }],
    defaultSize: { width: 140, height: 100 },
    execute: (_ctx, inputs) => ({ result: op(inputs.a, inputs.b) }),
    toCode: (_ctx, inputs) => ({
      assignments: { result: `(${inputs.a} ${opStr} ${inputs.b})` },
    }),
  };
}

registerNode(makeComparison("cmp_eq", "等于 (a == b)", "==", (a, b) => a === b));
registerNode(makeComparison("cmp_ne", "不等于 (a != b)", "!=", (a, b) => a !== b));
registerNode(makeComparison("cmp_gt", "大于 (a > b)", ">", (a, b) => (a as number) > (b as number)));
registerNode(makeComparison("cmp_lt", "小于 (a < b)", "<", (a, b) => (a as number) < (b as number)));
registerNode(makeComparison("cmp_ge", "大于等于 (a >= b)", ">=", (a, b) => (a as number) >= (b as number)));
registerNode(makeComparison("cmp_le", "小于等于 (a <= b)", "<=", (a, b) => (a as number) <= (b as number)));

// ---------------------------------------------------------------------------
// 4. 逻辑节点
// ---------------------------------------------------------------------------

registerNode({
  type: "logic_and",
  label: "与 (a and b)",
  category: "logic",
  inputs: [
    { id: "a", label: "a", type: "bool", default: true },
    { id: "b", label: "b", type: "bool", default: true },
  ],
  outputs: [{ id: "result", label: "结果", type: "bool" }],
  defaultSize: { width: 140, height: 100 },
  execute: (_ctx, inputs) => ({ result: Boolean(inputs.a) && Boolean(inputs.b) }),
  toCode: (_ctx, inputs) => ({ assignments: { result: `(${inputs.a} and ${inputs.b})` } }),
});

registerNode({
  type: "logic_or",
  label: "或 (a or b)",
  category: "logic",
  inputs: [
    { id: "a", label: "a", type: "bool", default: false },
    { id: "b", label: "b", type: "bool", default: false },
  ],
  outputs: [{ id: "result", label: "结果", type: "bool" }],
  defaultSize: { width: 140, height: 100 },
  execute: (_ctx, inputs) => ({ result: Boolean(inputs.a) || Boolean(inputs.b) }),
  toCode: (_ctx, inputs) => ({ assignments: { result: `(${inputs.a} or ${inputs.b})` } }),
});

registerNode({
  type: "logic_not",
  label: "非 (not a)",
  category: "logic",
  inputs: [{ id: "a", label: "a", type: "bool", default: false }],
  outputs: [{ id: "result", label: "结果", type: "bool" }],
  defaultSize: { width: 120, height: 80 },
  execute: (_ctx, inputs) => ({ result: !inputs.a }),
  toCode: (_ctx, inputs) => ({ assignments: { result: `(not ${inputs.a})` } }),
});

// ---------------------------------------------------------------------------
// 5. 容器节点
// ---------------------------------------------------------------------------

registerNode({
  type: "list_make",
  label: "构造列表",
  category: "container",
  description: "将多个输入打包为一个 list",
  inputs: [
    { id: "item0", label: "元素 0", type: "any" },
    { id: "item1", label: "元素 1", type: "any" },
    { id: "item2", label: "元素 2", type: "any" },
  ],
  outputs: [{ id: "list", label: "列表", type: "list" }],
  defaultSize: { width: 160, height: 140 },
  execute: (_ctx, inputs) => ({
    list: [inputs.item0 ?? null, inputs.item1 ?? null, inputs.item2 ?? null].filter(
      (v) => v !== undefined,
    ),
  }),
  toCode: (_ctx, inputs) => ({
    assignments: { list: `[${[inputs.item0, inputs.item1, inputs.item2].filter((v) => v !== undefined).join(", ")}]` },
  }),
});

registerNode({
  type: "list_length",
  label: "长度 (len)",
  category: "container",
  inputs: [{ id: "obj", label: "对象", type: "any", default: [] }],
  outputs: [{ id: "length", label: "长度", type: "int" }],
  defaultSize: { width: 140, height: 80 },
  execute: (_ctx, inputs) => {
    const obj = inputs.obj;
    if (Array.isArray(obj)) return { length: obj.length };
    if (typeof obj === "string") return { length: obj.length };
    if (typeof obj === "object" && obj !== null) {
      if (obj.__py_type === "dict") return { length: obj.entries.length };
      if (obj.__py_type === "tuple" || obj.__py_type === "set") return { length: obj.items.length };
      if (obj.__py_type === "range") {
        return { length: Math.max(0, Math.ceil((obj.stop - obj.start) / obj.step)) };
      }
    }
    return { length: 0 };
  },
  toCode: (_ctx, inputs) => ({ assignments: { length: `len(${inputs.obj})` } }),
});

registerNode({
  type: "list_index",
  label: "索引 (obj[i])",
  category: "container",
  inputs: [
    { id: "obj", label: "对象", type: "any", default: [] },
    { id: "index", label: "索引", type: "int", default: 0 },
  ],
  outputs: [{ id: "value", label: "元素", type: "any" }],
  defaultSize: { width: 140, height: 100 },
  execute: (_ctx, inputs) => {
    const obj = inputs.obj;
    const i = inputs.index as number;
    if (Array.isArray(obj)) return { value: obj[i] ?? null };
    if (typeof obj === "string") return { value: obj[i] ?? "" };
    if (typeof obj === "object" && obj !== null && obj.__py_type === "dict") {
      const entry = obj.entries.find(([k]) => k === inputs.index);
      return { value: entry ? entry[1] : null };
    }
    return { value: null };
  },
  toCode: (_ctx, inputs) => ({ assignments: { value: `${inputs.obj}[${inputs.index}]` } }),
});

registerNode({
  type: "list_append",
  label: "追加 (append)",
  category: "container",
  inputs: [
    { id: "list", label: "列表", type: "list", default: [] },
    { id: "item", label: "元素", type: "any" },
  ],
  outputs: [{ id: "result", label: "新列表", type: "list" }],
  defaultSize: { width: 160, height: 100 },
  execute: (_ctx, inputs) => {
    const list = Array.isArray(inputs.list) ? inputs.list : [];
    return { result: [...list, inputs.item] };
  },
  toCode: (_ctx, inputs) => ({
    assignments: { result: `${inputs.list} + [${inputs.item}]` },
  }),
});

registerNode({
  type: "range_node",
  label: "range(start, stop)",
  category: "container",
  inputs: [
    { id: "start", label: "start", type: "int", default: 0, editable: true },
    { id: "stop", label: "stop", type: "int", default: 10, editable: true },
    { id: "step", label: "step", type: "int", default: 1, editable: true },
  ],
  outputs: [{ id: "range", label: "range", type: "range" }],
  defaultSize: { width: 180, height: 140 },
  execute: (_ctx, inputs) => ({
    range: {
      __py_type: "range" as const,
      start: inputs.start as number,
      stop: inputs.stop as number,
      step: inputs.step as number,
    },
  }),
  toCode: (_ctx, inputs) => ({
    assignments: { range: `range(${inputs.start}, ${inputs.stop}, ${inputs.step})` },
  }),
});

// ---------------------------------------------------------------------------
// 6. 字符串节点
// ---------------------------------------------------------------------------

registerNode({
  type: "str_format",
  label: "字符串格式化 (f-string)",
  category: "string",
  inputs: [
    { id: "template", label: "模板", type: "str", default: "Hello, {0}!", editable: true },
    { id: "arg0", label: "参数 0", type: "any" },
    { id: "arg1", label: "参数 1", type: "any" },
  ],
  outputs: [{ id: "result", label: "结果", type: "str" }],
  defaultSize: { width: 200, height: 140 },
  execute: (_ctx, inputs) => {
    const template = inputs.template as string;
    const args = [inputs.arg0, inputs.arg1].filter((v) => v !== undefined);
    const result = template.replace(/\{(\d+)\}/g, (_, i) => pyStr(args[Number(i)] ?? ""));
    return { result };
  },
  toCode: (_ctx, inputs) => {
    const template = inputs.template;
    const args = [inputs.arg0, inputs.arg1].filter((v) => v !== undefined);
    const expr = template.replace(/\{(\d+)\}/g, (_, i) => `{${args[Number(i)] ?? "''"}}`);
    return { assignments: { result: `f${expr}` } };
  },
});

registerNode({
  type: "str_concat",
  label: "字符串拼接",
  category: "string",
  inputs: [
    { id: "a", label: "a", type: "str", default: "" },
    { id: "b", label: "b", type: "str", default: "" },
  ],
  outputs: [{ id: "result", label: "结果", type: "str" }],
  defaultSize: { width: 160, height: 100 },
  execute: (_ctx, inputs) => ({ result: pyStr(inputs.a) + pyStr(inputs.b) }),
  toCode: (_ctx, inputs) => ({ assignments: { result: `(${inputs.a} + ${inputs.b})` } }),
});

// ---------------------------------------------------------------------------
// 7. 控制流节点
// ---------------------------------------------------------------------------

/**
 * If 节点 — 根据条件选择 true_value 或 false_value 输出
 * 这是一个"纯选择器"模式, 不引入子图, 保持 DAG 简洁
 * 真正的 if/else 分支由子图实现 (在 DefineFunc 内或顶层子图)
 */
registerNode({
  type: "control_if",
  label: "条件选择 (If)",
  category: "control",
  isControlFlow: true,
  description: "根据 condition 选择输出 true_value 或 false_value",
  inputs: [
    { id: "condition", label: "条件", type: "bool", default: true },
    { id: "true_value", label: "真值", type: "any" },
    { id: "false_value", label: "假值", type: "any" },
  ],
  outputs: [{ id: "selected", label: "选中值", type: "any" }],
  defaultSize: { width: 180, height: 140 },
  execute: (_ctx, inputs) => ({
    selected: inputs.condition ? inputs.true_value : inputs.false_value,
  }),
  toCode: (_ctx, inputs) => ({
    assignments: {
      selected: `(${inputs.true_value} if ${inputs.condition} else ${inputs.false_value})`,
    },
  }),
});

/**
 * ForEach 节点 — 遍历可迭代对象, 输出每个元素
 * 简化模型: 直接输出 list 形式, 适合 DAG 解释
 * 完整的 for 循环控制流由子图实现 (在 DefineFunc 中)
 */
registerNode({
  type: "control_for_each",
  label: "遍历 (For Each)",
  category: "control",
  isControlFlow: true,
  description: "遍历可迭代对象, 输出元素列表",
  inputs: [{ id: "iterable", label: "可迭代", type: "any", default: [] }],
  outputs: [
    { id: "items", label: "元素列表", type: "list" },
    { id: "count", label: "数量", type: "int" },
  ],
  defaultSize: { width: 180, height: 100 },
  execute: (_ctx, inputs) => {
    const iter = inputs.iterable;
    let items: PyValue[] = [];
    if (Array.isArray(iter)) {
      items = iter;
    } else if (typeof iter === "string") {
      items = iter.split("");
    } else if (iter && typeof iter === "object" && iter.__py_type === "range") {
      items = [];
      const step = iter.step || 1;
      if (step > 0) {
        for (let i = iter.start; i < iter.stop; i += step) items.push(i);
      } else {
        for (let i = iter.start; i > iter.stop; i += step) items.push(i);
      }
    } else if (iter && typeof iter === "object" && iter.__py_type === "dict") {
      items = iter.entries.map(([k]) => k);
    } else if (iter && typeof iter === "object" && (iter.__py_type === "tuple" || iter.__py_type === "set")) {
      items = iter.items;
    }
    return { items, count: items.length };
  },
  toCode: (_ctx, inputs) => ({
    assignments: {
      items: `list(${inputs.iterable})`,
      count: `len(${inputs.iterable})`,
    },
  }),
});

/**
 * Filter 节点 — 用 callable 过滤列表
 * 在解释器中对 callable 进行实际调用
 */
registerNode({
  type: "control_filter",
  label: "过滤 (Filter)",
  category: "control",
  isControlFlow: true,
  description: "用函数过滤列表元素",
  inputs: [
    { id: "iterable", label: "列表", type: "list", default: [] },
    { id: "func", label: "过滤函数", type: "callable" },
  ],
  outputs: [{ id: "result", label: "结果", type: "list" }],
  defaultSize: { width: 180, height: 120 },
  execute: () => ({ result: [] }), // 由解释器特殊处理
  toCode: (_ctx, inputs) => ({
    assignments: { result: `list(filter(${inputs.func}, ${inputs.iterable}))` },
  }),
});

/**
 * Map 节点 — 用 callable 映射列表
 */
registerNode({
  type: "control_map",
  label: "映射 (Map)",
  category: "control",
  isControlFlow: true,
  description: "用函数映射列表元素",
  inputs: [
    { id: "iterable", label: "列表", type: "list", default: [] },
    { id: "func", label: "映射函数", type: "callable" },
  ],
  outputs: [{ id: "result", label: "结果", type: "list" }],
  defaultSize: { width: 180, height: 120 },
  execute: () => ({ result: [] }), // 由解释器特殊处理
  toCode: (_ctx, inputs) => ({
    assignments: { result: `list(map(${inputs.func}, ${inputs.iterable}))` },
  }),
});

// ---------------------------------------------------------------------------
// 8. 函数节点
// ---------------------------------------------------------------------------

/**
 * DefineFunc 节点 — 定义一个函数, 内部包含子图
 * 子图: 入口端口 = 函数参数, 出口端口 = 返回值
 */
registerNode({
  type: "func_define",
  label: "定义函数 (def)",
  category: "function",
  isSubgraph: true,
  description: "定义一个函数, 双击进入函数体子图",
  inputs: [
    { id: "param0", label: "参数 0", type: "any" },
    { id: "param1", label: "参数 1", type: "any" },
  ],
  outputs: [{ id: "func", label: "函数", type: "callable" }],
  defaultSize: { width: 200, height: 140 },
  execute: () => ({ func: null }), // 由解释器特殊处理: 创建闭包
  toCode: () => ({ assignments: { func: "" } }), // 由代码生成器特殊处理
});

/**
 * Call 节点 — 调用 callable
 */
registerNode({
  type: "func_call",
  label: "调用函数 (call)",
  category: "function",
  description: "调用一个函数, 传入参数, 返回结果",
  inputs: [
    { id: "func", label: "函数", type: "callable" },
    { id: "arg0", label: "参数 0", type: "any" },
    { id: "arg1", label: "参数 1", type: "any" },
  ],
  outputs: [{ id: "return", label: "返回值", type: "any" }],
  defaultSize: { width: 180, height: 140 },
  execute: () => ({ return: null }), // 由解释器特殊处理
  toCode: (_ctx, inputs) => ({
    assignments: {
      return: `${inputs.func}(${[inputs.arg0, inputs.arg1].filter((v) => v !== undefined).join(", ")})`,
    },
  }),
});

/**
 * Return 节点 — 在子图中标记返回值 (无 execute, 仅作为子图的出口标记)
 */
registerNode({
  type: "func_return",
  label: "返回值 (return)",
  category: "function",
  description: "标记函数的返回值 (放置在 DefineFunc 子图中)",
  inputs: [{ id: "value", label: "值", type: "any" }],
  outputs: [],
  defaultSize: { width: 160, height: 80 },
  execute: () => ({}), // 由解释器特殊处理
  toCode: () => ({ assignments: {}, statements: ["return {value}"] }),
});

// ---------------------------------------------------------------------------
// 9. 输入输出节点
// ---------------------------------------------------------------------------

registerNode({
  type: "io_print",
  label: "打印 (print)",
  category: "io",
  description: "将值打印到控制台",
  inputs: [{ id: "value", label: "值", type: "any" }],
  outputs: [],
  defaultSize: { width: 140, height: 80 },
  execute: (ctx, inputs) => {
    ctx.log(inputs.value);
    return {};
  },
  toCode: (_ctx, inputs) => ({
    assignments: {},
    statements: [`print(${inputs.value})`],
  }),
});

// ---------------------------------------------------------------------------
// 10. 模块节点
// ---------------------------------------------------------------------------

registerNode({
  type: "module_import",
  label: "导入模块 (import)",
  category: "module",
  description: "导入 Python 模块 (用于代码生成, 不实际执行)",
  inputs: [],
  outputs: [{ id: "module", label: "模块", type: "module" }],
  defaultSize: { width: 200, height: 100 },
  execute: (_ctx, _inputs) => ({
    module: { __py_type: "module" as const, name: "math" },
  }),
  toCode: () => ({
    assignments: { module: "math" },
    statements: [],
  }),
});

// ---------------------------------------------------------------------------
// 导出辅助函数 (供解释器/代码生成器使用)
// ---------------------------------------------------------------------------

export { pyRepr, pyStr, getParam };
