/**
 * 节点类型注册表
 * ------------------------------------------------------------------
 * 所有内置节点类型在此注册。注册表提供：
 *  - register()       注册新节点类型 (插件可扩展)
 *  - get()            获取节点类型定义
 *  - list()           列出所有节点类型
 *  - listByCategory() 按分类列出 (左侧面板使用)
 */

import type { NodeCategory, NodeTypeDef, PortDef, PyValue, WorkflowNode } from "./types";

const registry = new Map<string, NodeTypeDef>();

export function registerNode(def: NodeTypeDef): void {
  if (registry.has(def.type)) {
    console.warn(`[pyflow] Node type "${def.type}" is already registered, overwriting.`);
  }
  registry.set(def.type, def);
}

export function getNodeDef(type: string): NodeTypeDef | undefined {
  return registry.get(type);
}

export function listNodeTypes(): NodeTypeDef[] {
  return Array.from(registry.values());
}

export function listByCategory(): Record<NodeCategory, NodeTypeDef[]> {
  const result: Record<NodeCategory, NodeTypeDef[]> = {
    literal: [],
    operator: [],
    comparison: [],
    logic: [],
    container: [],
    string: [],
    control: [],
    function: [],
    io: [],
    module: [],
  };
  for (const def of registry.values()) {
    result[def.category].push(def);
  }
  return result;
}

/** 创建节点实例 (默认参数) */
export function createNodeInstance(
  type: string,
  id: string,
  pos: { x: number; y: number },
): WorkflowNode | null {
  const def = getNodeDef(type);
  if (!def) return null;

  // 收集所有端口的默认值作为初始参数
  const params: Record<string, PyValue> = {};
  for (const port of def.inputs) {
    if (port.default !== undefined) {
      params[port.id] = port.default;
    }
  }

  return {
    id,
    type,
    pos,
    params,
    _runtime: { status: "idle" },
  };
}

/** 获取节点的所有端口 (输入+输出) */
export function getAllPorts(node: WorkflowNode): { inputs: PortDef[]; outputs: PortDef[] } {
  const def = getNodeDef(node.type);
  return {
    inputs: def?.inputs ?? [],
    outputs: def?.outputs ?? [],
  };
}

/** 分类显示名 */
export const CATEGORY_LABELS: Record<NodeCategory, string> = {
  literal: "字面量",
  operator: "算术运算",
  comparison: "比较",
  logic: "逻辑",
  container: "容器",
  string: "字符串",
  control: "控制流",
  function: "函数",
  io: "输入输出",
  module: "模块",
};
