/**
 * PyFlowCode 代码生成器
 * ------------------------------------------------------------------
 * 将工作流图反向翻译为可读的 Python 脚本。
 *
 * 策略:
 *  1. 拓扑排序节点
 *  2. 对每个节点生成一个临时变量名 (如 _n1_result)
 *  3. 调用节点的 toCode() 获取表达式 + 语句
 *  4. 字面量节点直接生成 Python 字面量
 *  5. func_define 生成 def 块, 内部递归生成子图代码
 *  6. 输出完整 .py 文件 (含注释头)
 */

import { getNodeDef } from "./registry";
import { pyRepr } from "./builtin-nodes";
import type {
  CodeGenContext,
  PyValue,
  WorkflowEdge,
  WorkflowNode,
} from "./types";

// ---------------------------------------------------------------------------
// 拓扑排序 (复用)
// ---------------------------------------------------------------------------

function topologicalSort(nodes: WorkflowNode[], edges: WorkflowEdge[]): WorkflowNode[] {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const inDegree = new Map<string, number>();
  const outEdges = new Map<string, string[]>();

  for (const node of nodes) {
    inDegree.set(node.id, 0);
    outEdges.set(node.id, []);
  }

  for (const edge of edges) {
    if (!nodeMap.has(edge.from) || !nodeMap.has(edge.to)) continue;
    inDegree.set(edge.to, (inDegree.get(edge.to) ?? 0) + 1);
    outEdges.get(edge.from)?.push(edge.to);
  }

  const queue: string[] = [];
  for (const [id, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(id);
  }

  const sorted: WorkflowNode[] = [];
  while (queue.length > 0) {
    const id = queue.shift()!;
    const node = nodeMap.get(id);
    if (node) sorted.push(node);
    for (const next of outEdges.get(id) ?? []) {
      const newDeg = (inDegree.get(next) ?? 1) - 1;
      inDegree.set(next, newDeg);
      if (newDeg === 0) queue.push(next);
    }
  }

  for (const node of nodes) {
    if (!sorted.find((n) => n.id === node.id)) sorted.push(node);
  }

  return sorted;
}

// ---------------------------------------------------------------------------
// 代码生成器
// ---------------------------------------------------------------------------

export interface CodeGenOptions {
  /** 是否包含注释头 */
  header?: boolean;
  /** 缩进字符串 (默认 4 空格) */
  indent?: string;
}

export function generatePython(
  nodes: WorkflowNode[],
  edges: WorkflowEdge[],
  options: CodeGenOptions = {},
): string {
  const indent = options.indent ?? "    ";
  const sorted = topologicalSort(nodes, edges);

  // 节点 ID -> 变量名映射 (portId -> 表达式)
  const portExpr = new Map<string, string>(); // key = `${nodeId}.${portId}`

  // 已生成的语句
  const statements: string[] = [];

  // 已使用的变量名
  const usedNames = new Set<string>(["print", "range", "len", "filter", "map", "list", "dict", "set", "tuple", "str", "int", "float", "bool"]);

  // 函数定义收集 (放在最前)
  const funcDefs: string[] = [];

  // 生成唯一变量名
  function genVar(prefix: string): string {
    let i = 1;
    let name = `_${prefix}_${i}`;
    while (usedNames.has(name)) {
      i++;
      name = `_${prefix}_${i}`;
    }
    usedNames.add(name);
    return name;
  }

  // 获取端口的表达式
  function getInputExpr(nodeId: string, portId: string, fallback?: string): string {
    const edge = edges.find((e) => e.to === nodeId && e.toPort === portId);
    if (edge) {
      return portExpr.get(`${edge.from}.${edge.fromPort}`) ?? "None";
    }
    // 无连线: 使用节点参数或默认值
    const node = nodes.find((n) => n.id === nodeId);
    if (node) {
      const def = getNodeDef(node.type);
      const port = def?.inputs.find((p) => p.id === portId);
      if (node.params[portId] !== undefined) {
        return pyRepr(node.params[portId]);
      }
      if (port?.default !== undefined) {
        return pyRepr(port.default);
      }
    }
    return fallback ?? "None";
  }

  // 处理每个节点
  for (const node of sorted) {
    const def = getNodeDef(node.type);
    if (!def) continue;

    // 特殊: 字面量节点
    if (
      node.type === "literal_int" ||
      node.type === "literal_float" ||
      node.type === "literal_str" ||
      node.type === "literal_bool" ||
      node.type === "literal_none"
    ) {
      const expr = node.type === "literal_none" ? "None" : pyRepr(node.params.value ?? null);
      portExpr.set(`${node.id}.value`, expr);
      continue;
    }

    // 特殊: 函数定义
    if (node.type === "func_define") {
      const funcName = genVar("func");
      const paramNames = def.inputs.map((p) => p.id);
      const header = `def ${funcName}(${paramNames.join(", ")}):`;

      // 收集子图代码
      const subStatements: string[] = [];
      const subPortExpr = new Map<string, string>();
      if (node.subgraph && node.subgraph.nodes.length > 0) {
        const subSorted = topologicalSort(node.subgraph.nodes, node.subgraph.edges);

        // 在子作用域内执行
        const subUsedNames = new Set(usedNames);

        // 复用顶层生成逻辑 (递归处理)
        for (const subNode of subSorted) {
          const subDef = getNodeDef(subNode.type);
          if (!subDef) continue;

          if (
            subNode.type === "literal_int" ||
            subNode.type === "literal_float" ||
            subNode.type === "literal_str" ||
            subNode.type === "literal_bool"
          ) {
            subPortExpr.set(`${subNode.id}.value`, pyRepr(subNode.params.value ?? null));
            continue;
          }

          if (subNode.type === "func_return") {
            const valueExpr = subPortExpr.get(
              `${(node.subgraph!.edges.find((e) => e.to === subNode.id && e.toPort === "value") ?? { from: "", fromPort: "" }).from}.${(node.subgraph!.edges.find((e) => e.to === subNode.id && e.toPort === "value") ?? { from: "", fromPort: "" }).fromPort}`,
            ) ?? "None";
            subStatements.push(`${indent}return ${valueExpr}`);
            continue;
          }

          // 收集输入表达式
          const subInputExprs: Record<string, string> = {};
          for (const port of subDef.inputs) {
            const edge = node.subgraph!.edges.find((e) => e.to === subNode.id && e.toPort === port.id);
            if (edge) {
              subInputExprs[port.id] = subPortExpr.get(`${edge.from}.${edge.fromPort}`) ?? "None";
            } else if (paramNames.includes(port.id)) {
              subInputExprs[port.id] = port.id; // 参数引用
            } else if (subNode.params[port.id] !== undefined) {
              subInputExprs[port.id] = pyRepr(subNode.params[port.id]);
            } else {
              subInputExprs[port.id] = "None";
            }
          }

          if (subDef.toCode) {
            const result = subDef.toCode({ statements: subStatements, usedNames: subUsedNames, indent: 1 }, subInputExprs);
            for (const [portId, expr] of Object.entries(result.assignments)) {
              const varName = genVar.call({ usedNames: subUsedNames }, "v");
              subUsedNames.add(varName);
              subPortExpr.set(`${subNode.id}.${portId}`, varName);
              subStatements.push(`${indent}${varName} = ${expr}`);
            }
            if (result.statements) {
              for (const stmt of result.statements) {
                subStatements.push(`${indent}${stmt.replace("{value}", subInputExprs.value ?? "None")}`);
              }
            }
          }
        }
      }

      if (subStatements.length === 0) {
        subStatements.push(`${indent}pass`);
      }

      funcDefs.push(`${header}\n${subStatements.join("\n")}`);
      portExpr.set(`${node.id}.func`, funcName);
      continue;
    }

    // 收集输入表达式
    const inputExprs: Record<string, string> = {};
    for (const port of def.inputs) {
      inputExprs[port.id] = getInputExpr(node.id, port.id);
    }

    // 调用节点的 toCode
    if (!def.toCode) {
      // 无 toCode, 跳过
      continue;
    }

    const ctx: CodeGenContext = {
      statements,
      usedNames,
      indent: 0,
    };

    const result = def.toCode(ctx, inputExprs);

    // 处理语句
    if (result.statements) {
      for (const stmt of result.statements) {
        // 替换 {value} 占位符
        statements.push(stmt.replace("{value}", inputExprs.value ?? "None"));
      }
    }

    // 处理输出端口 -> 变量名
    for (const [portId, expr] of Object.entries(result.assignments)) {
      const varName = genVar("v");
      if (expr) {
        statements.push(`${varName} = ${expr}`);
      }
      portExpr.set(`${node.id}.${portId}`, varName);
    }
  }

  // 组装最终代码
  const lines: string[] = [];

  if (options.header !== false) {
    lines.push("#!/usr/bin/env python3");
    lines.push("# -*- coding: utf-8 -*-");
    lines.push('"""');
    lines.push("由 PyFlowCode 节点式编辑器生成");
    lines.push("https://github.com/your-org/pyflowcode");
    lines.push('"""');
    lines.push("");
  }

  // 先放函数定义
  if (funcDefs.length > 0) {
    lines.push(...funcDefs);
    lines.push("");
  }

  // 主流程语句
  if (statements.length === 0) {
    lines.push("pass");
  } else {
    lines.push(...statements);
  }

  return lines.join("\n");
}
