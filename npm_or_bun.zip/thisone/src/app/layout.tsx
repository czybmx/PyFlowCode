import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PyFlowCode - 节点式 Python 代码可视化编辑器",
  description: "像 ComfyUI 一样, 通过拖拽节点和连线编写 Python 代码。所见即所得的可视化编程, 一键导出标准 .py 文件。",
  keywords: ["PyFlowCode", "节点编辑器", "可视化编程", "Python", "ComfyUI", "Node Editor"],
  authors: [{ name: "PyFlowCode" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "PyFlowCode - 节点式 Python 编辑器",
    description: "拖拽节点, 连线编程, 一键导出 Python 代码",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
