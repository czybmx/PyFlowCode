"use client";

/**
 * 工具栏 (顶部)
 * ------------------------------------------------------------------
 * 操作按钮:
 *  - ▶ 运行工作流
 *  - 🔄 重置运行状态
 *  - 📋 生成 Python 代码 (弹窗)
 *  - 💾 导出 .pyflow JSON
 *  - 📂 导入 .pyflow JSON
 *  - 🧹 清空画布
 *  - 📚 加载示例
 */

import { useRef, useState } from "react";
import { useWorkflowStore } from "@/store/workflow";
import {
  Play,
  FileCode,
  Download,
  Upload,
  Trash2,
  BookOpen,
  Code2,
  X,
  Copy,
  Check,
} from "lucide-react";
import { EXAMPLES, type ExampleKey } from "./examples";

export function Toolbar() {
  const store = useWorkflowStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [copied, setCopied] = useState(false);
  const [examplesOpen, setExamplesOpen] = useState(false);

  const handleExport = () => {
    const doc = store.exportDocument();
    const blob = new Blob([JSON.stringify(doc, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `workflow-${Date.now()}.pyflow`;
    a.click();
    URL.revokeObjectURL(url);
    store.consoleLog("info", "✓ 工作流已导出为 .pyflow 文件");
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const doc = JSON.parse(ev.target?.result as string);
        if (!doc.nodes || !doc.edges) throw new Error("无效的 .pyflow 文件");
        store.loadDocument(doc);
        store.consoleLog("info", `✓ 已加载工作流 (${doc.nodes.length} 节点, ${doc.edges.length} 连线)`);
      } catch (err) {
        store.consoleLog("error", `导入失败: ${err instanceof Error ? err.message : String(err)}`);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleClear = () => {
    if (confirm("确定要清空当前画布吗?")) {
      store.reset();
      store.consoleLog("info", "画布已清空");
    }
  };

  const handleExample = (key: ExampleKey) => {
    const example = EXAMPLES[key];
    store.loadDocument(example);
    store.consoleLog("info", `✓ 已加载示例: ${example.name}`);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(store.generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCode = () => {
    const blob = new Blob([store.generatedCode], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pyflow_generated.py";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="flex items-center gap-1 px-3 py-2 bg-[#1e1e24] border-b border-zinc-800">
        {/* Logo */}
        <div className="flex items-center gap-2 mr-4">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-xs font-bold text-white">
            Py
          </div>
          <span className="text-sm font-medium text-zinc-200">PyFlowCode</span>
          <span className="text-[10px] text-zinc-600 ml-1">节点式 Python 编辑器</span>
        </div>

        <div className="w-px h-5 bg-zinc-700 mx-2" />

        {/* 运行 */}
        <button
          onClick={store.run}
          disabled={store.isRunning}
          className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 disabled:opacity-50 border border-emerald-600/40 text-emerald-300 rounded text-xs"
        >
          <Play className="w-3 h-3" />
          {store.isRunning ? "运行中..." : "运行"}
        </button>

        {/* 生成代码 */}
        <button
          onClick={store.generateCode}
          className="flex items-center gap-1.5 px-3 py-1 bg-sky-600/20 hover:bg-sky-600/30 border border-sky-600/40 text-sky-300 rounded text-xs"
        >
          <FileCode className="w-3 h-3" />
          生成 Python
        </button>

        <div className="w-px h-5 bg-zinc-700 mx-2" />

        {/* 文件操作 */}
        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-2 py-1 hover:bg-zinc-800 text-zinc-400 rounded text-xs"
        >
          <Download className="w-3 h-3" />
          导出
        </button>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 px-2 py-1 hover:bg-zinc-800 text-zinc-400 rounded text-xs"
        >
          <Upload className="w-3 h-3" />
          导入
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".pyflow,.json"
          onChange={handleImport}
          className="hidden"
        />

        <div className="w-px h-5 bg-zinc-700 mx-2" />

        {/* 示例 */}
        <div className="relative">
          <button
            onClick={() => setExamplesOpen((v) => !v)}
            className="flex items-center gap-1.5 px-2 py-1 hover:bg-zinc-800 text-zinc-400 rounded text-xs"
          >
            <BookOpen className="w-3 h-3" />
            示例
          </button>
          {examplesOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setExamplesOpen(false)} />
              <div className="absolute left-0 top-full mt-1 bg-zinc-900 border border-zinc-700 rounded shadow-xl py-1 z-50 min-w-48">
                {(Object.keys(EXAMPLES) as ExampleKey[]).map((key) => (
                  <button
                    key={key}
                    onClick={() => {
                      handleExample(key);
                      setExamplesOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-zinc-800 text-xs text-zinc-300"
                  >
                    <div className="font-medium">{EXAMPLES[key].name}</div>
                    <div className="text-[10px] text-zinc-500">{EXAMPLES[key].description}</div>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* 清空 */}
        <button
          onClick={handleClear}
          className="flex items-center gap-1.5 px-2 py-1 hover:bg-red-900/30 hover:text-red-300 text-zinc-400 rounded text-xs"
        >
          <Trash2 className="w-3 h-3" />
          清空
        </button>

        {/* 子图导航 (面包屑) */}
        {store.subgraphPath.nodeIds.length > 0 && (
          <>
            <div className="w-px h-5 bg-zinc-700 mx-2" />
            <div className="flex items-center gap-1 text-xs">
              <button
                onClick={() => store.exitToRoot()}
                className="px-2 py-1 hover:bg-zinc-800 text-amber-300 rounded"
              >
                顶层
              </button>
              {store.subgraphPath.labels.map((label, i) => (
                <div key={i} className="flex items-center gap-1">
                  <span className="text-zinc-600">/</span>
                  <button
                    onClick={() => store.navigateTo(i)}
                    className={`px-2 py-1 rounded ${
                      i === store.subgraphPath.labels.length - 1
                        ? "bg-amber-500/20 text-amber-300"
                        : "hover:bg-zinc-800 text-zinc-300"
                    }`}
                  >
                    {label}
                  </button>
                </div>
              ))}
              <button
                onClick={() => store.exitSubgraph()}
                className="ml-2 px-2 py-1 hover:bg-zinc-800 text-zinc-400 rounded"
              >
                ← 返回上层
              </button>
            </div>
          </>
        )}

        {/* 状态指示 */}
        <div className="ml-auto flex items-center gap-3 text-[10px] text-zinc-500">
          <span>{store.nodes.length} 节点</span>
          <span>{store.edges.length} 连线</span>
        </div>
      </div>

      {/* 代码生成弹窗 */}
      {store.showCodeGen && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => store.setShowCodeGen(false)}
        >
          <div
            className="bg-[#1e1e24] border border-zinc-700 rounded-lg shadow-2xl w-full max-w-4xl max-h-[80vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-medium text-zinc-200">生成的 Python 代码</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2 py-1 hover:bg-zinc-800 text-xs text-zinc-400 rounded"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? "已复制" : "复制"}
                </button>
                <button
                  onClick={handleDownloadCode}
                  className="flex items-center gap-1 px-2 py-1 hover:bg-zinc-800 text-xs text-zinc-400 rounded"
                >
                  <Download className="w-3 h-3" />
                  下载 .py
                </button>
                <button
                  onClick={() => store.setShowCodeGen(false)}
                  className="p-1 hover:bg-zinc-800 text-zinc-400 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <pre className="text-xs text-zinc-300 font-mono whitespace-pre-wrap leading-relaxed">
                {store.generatedCode || "// 点击\"生成 Python\"按钮查看代码"}
              </pre>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
