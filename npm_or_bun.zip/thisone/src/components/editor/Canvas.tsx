"use client";

/**
 * 节点画布
 * ------------------------------------------------------------------
 * 实现类 ComfyUI 的画布交互:
 *  - 无限画布 (平移: 拖拽空白处 / 缩放: 滚轮)
 *  - 节点拖拽 (拖拽节点头部移动)
 *  - 端口连线 (从输出端口拖到输入端口)
 *  - 类型颜色提示 (端口圆点颜色)
 *  - 连线预览 (拖拽时显示临时连线)
 *  - 节点选中 (单击)
 *  - 子图进入 (双击 DefineFunc)
 *  - 删除节点 (Delete 键)
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useWorkflowStore } from "@/store/workflow";
import { getNodeDef, listNodeTypes } from "@/lib/pyflow/registry";
import { isTypeCompatible, getTypeColor, getTypeLabel } from "@/lib/pyflow/types";
import type { PyType, PyValue, WorkflowEdge, WorkflowNode } from "@/lib/pyflow/types";
import { NodeView } from "./NodeView";
import { EdgeView } from "./EdgeView";
import { PortTooltip } from "./PortTooltip";

interface PendingConnection {
  fromNodeId: string;
  fromPortId: string;
  fromPos: { x: number; y: number };
  toPos: { x: number; y: number };
}

interface DragState {
  nodeId: string;
  offset: { x: number; y: number };
}

export function Canvas() {
  const store = useWorkflowStore();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [pendingConnection, setPendingConnection] = useState<PendingConnection | null>(null);
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [hoveredPort, setHoveredPort] = useState<{
    nodeId: string;
    portId: string;
    type: PyType;
    pos: { x: number; y: number };
    direction: "input" | "output";
  } | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  const panStartRef = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null);

  // 获取当前层级的节点和连线
  const nodes = store.getCurrentNodes();
  const edges = store.getCurrentEdges();

  // 端口位置缓存 (用于绘制连线)
  const [portPositions, setPortPositions] = useState<
    Map<string, { x: number; y: number; type: PyType; direction: "input" | "output" }>
  >(new Map());

  // 更新端口位置 (子组件回调)
  const registerPortPosition = useCallback(
    (nodeId: string, portId: string, pos: { x: number; y: number }, type: PyType, direction: "input" | "output") => {
      setPortPositions((prev) => {
        const key = `${nodeId}.${portId}.${direction}`;
        const existing = prev.get(key);
        if (existing && existing.x === pos.x && existing.y === pos.y && existing.type === type) {
          return prev;
        }
        const next = new Map(prev);
        next.set(key, { ...pos, type, direction });
        return next;
      });
    },
    [],
  );

  // 计算端口在画布坐标系中的位置
  const getPortPos = useCallback(
    (nodeId: string, portId: string, direction: "input" | "output"): { x: number; y: number; type: PyType } | null => {
      const key = `${nodeId}.${portId}.${direction}`;
      const pos = portPositions.get(key);
      if (pos) return { x: pos.x, y: pos.y, type: pos.type };
      return null;
    },
    [portPositions],
  );

  // -------------------------------------------------------------------------
  // 画布交互: 平移
  // -------------------------------------------------------------------------

  const onCanvasMouseDown = (e: React.MouseEvent) => {
    // 仅在点击空白处时触发
    if (e.target !== e.currentTarget && (e.target as HTMLElement).closest("[data-node-id]")) {
      return;
    }
    if (e.button === 0) {
      // 左键: 平移 + 取消选中
      setIsPanning(true);
      panStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        panX: store.canvas.pan.x,
        panY: store.canvas.pan.y,
      };
      store.selectNode(null);
    }
  };

  useEffect(() => {
    if (!isPanning) return;
    const onMove = (e: MouseEvent) => {
      if (!panStartRef.current) return;
      const dx = e.clientX - panStartRef.current.x;
      const dy = e.clientY - panStartRef.current.y;
      store.setCanvas({
        pan: {
          x: panStartRef.current.panX + dx,
          y: panStartRef.current.panY + dy,
        },
      });
    };
    const onUp = () => {
      setIsPanning(false);
      panStartRef.current = null;
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [isPanning, store]);

  // -------------------------------------------------------------------------
  // 画布交互: 缩放
  // -------------------------------------------------------------------------

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = -e.deltaY * 0.001;
    const newZoom = Math.max(0.2, Math.min(3, store.canvas.zoom + delta));
    store.setCanvas({ zoom: newZoom });
  };

  // -------------------------------------------------------------------------
  // 节点拖拽
  // -------------------------------------------------------------------------

  const startNodeDrag = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation();
    const node = nodes.find((n) => n.id === nodeId);
    if (!node) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    // 计算鼠标在画布坐标系中的位置
    const canvasX = (e.clientX - rect.left - store.canvas.pan.x) / store.canvas.zoom;
    const canvasY = (e.clientY - rect.top - store.canvas.pan.y) / store.canvas.zoom;

    setDragState({
      nodeId,
      offset: {
        x: canvasX - node.pos.x,
        y: canvasY - node.pos.y,
      },
    });
    store.selectNode(nodeId);
  };

  useEffect(() => {
    if (!dragState) return;
    const onMove = (e: MouseEvent) => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      const canvasX = (e.clientX - rect.left - store.canvas.pan.x) / store.canvas.zoom;
      const canvasY = (e.clientY - rect.top - store.canvas.pan.y) / store.canvas.zoom;
      store.moveNode(dragState.nodeId, {
        x: canvasX - dragState.offset.x,
        y: canvasY - dragState.offset.y,
      });
    };
    const onUp = () => setDragState(null);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [dragState, store]);

  // -------------------------------------------------------------------------
  // 端口连线
  // -------------------------------------------------------------------------

  const startConnection = (
    e: React.MouseEvent,
    nodeId: string,
    portId: string,
    direction: "input" | "output",
  ) => {
    e.stopPropagation();
    const portPos = getPortPos(nodeId, portId, direction);
    if (!portPos) return;

    // 总是从 output 拖到 input; 如果从 input 开始, 反向
    if (direction === "output") {
      setPendingConnection({
        fromNodeId: nodeId,
        fromPortId: portId,
        fromPos: portPos,
        toPos: portPos,
      });
    } else {
      // 从 input 拖: 反向, 需要找到一个 output 上的源
      // 简化: 不允许从 input 开始拖
      // 但 ComfyUI 是允许的, 我们也允许
      // 此时 pendingConnection 反向: 目标是当前 input
      // 但我们暂时不支持
      return;
    }

    const onMove = (ev: MouseEvent) => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      const canvasX = (ev.clientX - rect.left - store.canvas.pan.x) / store.canvas.zoom;
      const canvasY = (ev.clientY - rect.top - store.canvas.pan.y) / store.canvas.zoom;
      setPendingConnection((prev) =>
        prev ? { ...prev, toPos: { x: canvasX, y: canvasY } } : null,
      );
    };
    const onUp = (ev: MouseEvent) => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);

      // 检查鼠标是否在某个 input 端口上
      const target = document.elementFromPoint(ev.clientX, ev.clientY) as HTMLElement | null;
      const portEl = target?.closest("[data-port]") as HTMLElement | null;
      if (portEl) {
        const targetNodeId = portEl.dataset.portNodeId!;
        const targetPortId = portEl.dataset.portId!;
        const targetDir = portEl.dataset.portDir as "input" | "output";
        if (targetDir === "input" && targetNodeId !== nodeId) {
          // 类型检查
          const fromNode = nodes.find((n) => n.id === nodeId);
          const toNode = nodes.find((n) => n.id === targetNodeId);
          if (fromNode && toNode) {
            const fromDef = getNodeDef(fromNode.type);
            const toDef = getNodeDef(toNode.type);
            const fromPortDef = fromDef?.outputs.find((p) => p.id === portId);
            const toPortDef = toDef?.inputs.find((p) => p.id === targetPortId);
            if (fromPortDef && toPortDef && isTypeCompatible(fromPortDef.type, toPortDef.type)) {
              store.addEdge(nodeId, portId, targetNodeId, targetPortId);
            }
          }
        }
      }
      setPendingConnection(null);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  // -------------------------------------------------------------------------
  // 键盘事件: 删除节点/连线
  // -------------------------------------------------------------------------

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // 只在没有 input 聚焦时响应
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) return;

      if ((e.key === "Delete" || e.key === "Backspace") && store.selectedNodeId) {
        store.removeNode(store.selectedNodeId);
        e.preventDefault();
      }
      if ((e.key === "Delete" || e.key === "Backspace") && store.selectedEdgeId) {
        store.removeEdge(store.selectedEdgeId);
        e.preventDefault();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [store]);

  // -------------------------------------------------------------------------
  // 双击节点: 进入子图
  // -------------------------------------------------------------------------

  const onNodeDoubleClick = (node: WorkflowNode) => {
    const def = getNodeDef(node.type);
    if (def?.isSubgraph) {
      store.enterSubgraph(node.id);
    }
  };

  // -------------------------------------------------------------------------
  // 渲染
  // -------------------------------------------------------------------------

  const transform = `translate(${store.canvas.pan.x}px, ${store.canvas.pan.y}px) scale(${store.canvas.zoom})`;

  return (
    <div
      ref={canvasRef}
      className="relative w-full h-full overflow-hidden bg-[#1a1a1f] cursor-grab active:cursor-grabbing"
      onMouseDown={onCanvasMouseDown}
      onWheel={onWheel}
      style={{
        backgroundImage:
          "radial-gradient(circle, #2a2a32 1px, transparent 1px)",
        backgroundSize: "24px 24px",
        backgroundPosition: `${store.canvas.pan.x}px ${store.canvas.pan.y}px`,
      }}
    >
      {/* 画布内容 */}
      <div
        className="absolute top-0 left-0 origin-top-left"
        style={{ transform, transformOrigin: "0 0" }}
      >
        {/* 连线层 (SVG) */}
        <svg
          className="absolute top-0 left-0 pointer-events-none"
          width="10000"
          height="10000"
          style={{ overflow: "visible" }}
        >
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="10"
              refX="8"
              refY="5"
              orient="auto"
            >
              <polygon points="0 0, 10 5, 0 10" fill="#666" />
            </marker>
          </defs>

          {edges.map((edge) => {
            const from = getPortPos(edge.from, edge.fromPort, "output");
            const to = getPortPos(edge.to, edge.toPort, "input");
            if (!from || !to) return null;
            return (
              <EdgeView
                key={edge.id}
                edge={edge}
                from={from}
                to={to}
                selected={store.selectedEdgeId === edge.id}
                onSelect={() => store.selectEdge(edge.id)}
              />
            );
          })}

          {/* 临时连线 (拖拽中) */}
          {pendingConnection && (
            <EdgeView
              edge={{
                id: "pending",
                from: pendingConnection.fromNodeId,
                fromPort: pendingConnection.fromPortId,
                to: "",
                toPort: "",
              }}
              from={pendingConnection.fromPos}
              to={pendingConnection.toPos}
              selected={false}
              onSelect={() => {}}
              isPending
            />
          )}
        </svg>

        {/* 节点层 */}
        {nodes.map((node) => (
          <NodeView
            key={node.id}
            node={node}
            selected={store.selectedNodeId === node.id}
            zoom={store.canvas.zoom}
            onSelect={() => store.selectNode(node.id)}
            onDragStart={(e) => startNodeDrag(e, node.id)}
            onDoubleClick={() => onNodeDoubleClick(node)}
            onPortMouseDown={(e, portId, direction) =>
              startConnection(e, node.id, portId, direction)
            }
            onPortHover={(portId, direction, pos, type) => {
              const portPos = getPortPos(node.id, portId, direction);
              if (portPos) {
                setHoveredPort({
                  nodeId: node.id,
                  portId,
                  type: portPos.type,
                  pos: { x: portPos.x, y: portPos.y },
                  direction,
                });
              } else {
                setHoveredPort({
                  nodeId: node.id,
                  portId,
                  type,
                  pos,
                  direction,
                });
              }
            }}
            onPortLeave={() => setHoveredPort(null)}
            registerPortPosition={registerPortPosition}
            canvasPan={store.canvas.pan}
            canvasZoom={store.canvas.zoom}
            canvasRef={canvasRef}
          />
        ))}
      </div>

      {/* 端口 tooltip */}
      {hoveredPort && (
        <PortTooltip
          port={hoveredPort}
          node={nodes.find((n) => n.id === hoveredPort.nodeId)}
        />
      )}

      {/* 空状态提示 */}
      {nodes.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-center text-gray-500">
            <div className="text-2xl mb-2">节点式 Python 编辑器</div>
            <div className="text-sm">从左侧拖入节点开始构建你的 Python 程序</div>
            <div className="text-xs mt-4 text-gray-600">
              滚轮缩放 · 拖拽空白处平移 · 拖拽端口连线 · Delete 删除
            </div>
          </div>
        </div>
      )}

      {/* 缩放控件 */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-1 z-10">
        <button
          className="w-8 h-8 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded border border-zinc-700 text-sm"
          onClick={() => store.setCanvas({ zoom: Math.min(3, store.canvas.zoom + 0.1) })}
        >
          +
        </button>
        <button
          className="w-8 h-8 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded border border-zinc-700 text-xs"
          onClick={() => store.setCanvas({ zoom: 1, pan: { x: 0, y: 0 } })}
        >
          {Math.round(store.canvas.zoom * 100)}%
        </button>
        <button
          className="w-8 h-8 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded border border-zinc-700 text-sm"
          onClick={() => store.setCanvas({ zoom: Math.max(0.2, store.canvas.zoom - 0.1) })}
        >
          −
        </button>
      </div>
    </div>
  );
}
