"use client";

/**
 * 端口悬停气泡
 * ------------------------------------------------------------------
 * 鼠标悬停在端口上时显示:
 *  - 类型名
 *  - 当前值 (如果已执行)
 */

import type { PyType, WorkflowNode } from "@/lib/pyflow/types";
import { getTypeColor, getTypeLabel } from "@/lib/pyflow/types";

interface PortTooltipProps {
  port: {
    nodeId: string;
    portId: string;
    type: PyType;
    pos: { x: number; y: number };
    direction: "input" | "output";
  };
  node?: WorkflowNode;
}

export function PortTooltip({ port, node }: PortTooltipProps) {
  const color = getTypeColor(port.type);
  const typeLabel = getTypeLabel(port.type);

  // 获取当前值 (如果已执行)
  const currentValue =
    port.direction === "output"
      ? node?._runtime?.outputs?.[port.portId]
      : undefined;

  const valueStr = formatPyValue(currentValue);

  return (
    <div
      className="absolute z-50 pointer-events-none bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-[10px] shadow-xl"
      style={{
        left: port.pos.x + 12,
        top: port.pos.y - 6,
      }}
    >
      <div className="flex items-center gap-1.5">
        <span
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: color }}
        />
        <span className="text-zinc-300 font-mono">{typeLabel}</span>
        <span className="text-zinc-500">·</span>
        <span className="text-zinc-500">{port.direction === "input" ? "输入" : "输出"}</span>
      </div>
      {currentValue !== undefined && (
        <div className="mt-0.5 text-zinc-400 font-mono max-w-64 truncate">
          = {valueStr}
        </div>
      )}
    </div>
  );
}

function formatPyValue(v: unknown): string {
  if (v === undefined) return "undefined";
  if (v === null) return "None";
  if (typeof v === "string") return `"${v.length > 40 ? v.slice(0, 40) + "..." : v}"`;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return `[${v.length} 项]`;
  if (typeof v === "object") {
    const obj = v as { __py_type?: string };
    if (obj.__py_type === "dict") return `{${obj.entries?.length ?? 0} 项}`;
    if (obj.__py_type === "callable") return `<func ${obj.name}>`;
    if (obj.__py_type === "module") return `<module ${obj.name}>`;
    if (obj.__py_type === "range") return `range(...)`;
  }
  return String(v);
}
