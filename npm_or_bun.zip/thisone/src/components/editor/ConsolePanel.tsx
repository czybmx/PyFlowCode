"use client";

/**
 * 控制台面板 (右侧下半)
 * ------------------------------------------------------------------
 * 显示工作流运行时的输出:
 *  - log  (Print 节点产生, 默认色)
 *  - info (运行开始/结束等, 蓝色)
 *  - error(节点执行错误, 红色)
 */

import { useEffect, useRef } from "react";
import { useWorkflowStore } from "@/store/workflow";
import { Trash2, Terminal } from "lucide-react";

export function ConsolePanel() {
  const consoleOutput = useWorkflowStore((s) => s.consoleOutput);
  const clearConsole = useWorkflowStore((s) => s.clearConsole);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [consoleOutput]);

  return (
    <div className="flex flex-col h-full bg-[#1a1a1f]">
      {/* 头部 */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800">
        <div className="flex items-center gap-2 text-[11px] text-zinc-400">
          <Terminal className="w-3 h-3" />
          <span>控制台</span>
          <span className="text-zinc-600">({consoleOutput.length})</span>
        </div>
        <button
          onClick={clearConsole}
          className="text-zinc-500 hover:text-zinc-300"
          title="清空"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>

      {/* 输出区 */}
      <div className="flex-1 overflow-y-auto p-2 font-mono text-[11px] leading-relaxed">
        {consoleOutput.length === 0 ? (
          <div className="text-zinc-600 italic px-1 py-2">
            点击工具栏的"运行"按钮查看输出
          </div>
        ) : (
          consoleOutput.map((entry, i) => (
            <div
              key={i}
              className={`px-1 py-0.5 ${
                entry.type === "error"
                  ? "text-red-400"
                  : entry.type === "info"
                  ? "text-sky-400"
                  : "text-zinc-300"
              }`}
            >
              <span className="text-zinc-600 mr-2">
                [{new Date(entry.timestamp).toLocaleTimeString()}]
              </span>
              {entry.message}
            </div>
          ))
        )}
        <div ref={endRef} />
      </div>
    </div>
  );
}
