"use client";

/**
 * 参数编辑器
 * ------------------------------------------------------------------
 * 用于字面量节点 (Literal) 等无输入端口的节点
 * 提供值编辑: int/float 用 number input, str 用 textarea, bool 用 select
 */

import { useWorkflowStore } from "@/store/workflow";
import type { PortDef, PyValue, WorkflowNode } from "@/lib/pyflow/types";

interface ParamEditorProps {
  node: WorkflowNode;
  port: PortDef;
}

export function ParamEditor({ node, port }: ParamEditorProps) {
  const updateNodeParam = useWorkflowStore((s) => s.updateNodeParam);
  const value: PyValue = node.params[port.id] ?? port.default ?? getDefaultForType(port.type);

  const setValue = (v: PyValue) => updateNodeParam(node.id, port.id, v);

  if (port.type === "int") {
    return (
      <div className="flex items-center gap-2">
        <span className="text-[10px] text-zinc-500">值:</span>
        <input
          type="number"
          step={1}
          value={typeof value === "number" ? value : 0}
          onChange={(e) => setValue(Math.trunc(Number(e.target.value) || 0))}
          className="flex-1 bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-xs text-zinc-100 focus:border-amber-500 focus:outline-none"
        />
      </div>
    );
  }

  if (port.type === "float") {
    return (
      <div className="flex items-center gap-2">
        <span className="text-[10px] text-zinc-500">值:</span>
        <input
          type="number"
          step={0.1}
          value={typeof value === "number" ? value : 0}
          onChange={(e) => setValue(Number(e.target.value) || 0)}
          className="flex-1 bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-xs text-zinc-100 focus:border-amber-500 focus:outline-none"
        />
      </div>
    );
  }

  if (port.type === "bool") {
    return (
      <div className="flex items-center gap-2">
        <span className="text-[10px] text-zinc-500">值:</span>
        <select
          value={value === true ? "true" : "false"}
          onChange={(e) => setValue(e.target.value === "true")}
          className="flex-1 bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-xs text-zinc-100 focus:border-amber-500 focus:outline-none"
        >
          <option value="true">True</option>
          <option value="false">False</option>
        </select>
      </div>
    );
  }

  if (port.type === "str") {
    return (
      <div className="flex flex-col gap-1">
        <span className="text-[10px] text-zinc-500">值:</span>
        <textarea
          value={typeof value === "string" ? value : ""}
          onChange={(e) => setValue(e.target.value)}
          rows={2}
          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-100 focus:border-amber-500 focus:outline-none resize-none font-mono"
        />
      </div>
    );
  }

  return (
    <div className="text-[10px] text-zinc-500">
      此类型 ({port.type}) 暂不支持内联编辑
    </div>
  );
}

function getDefaultForType(type: string): PyValue {
  switch (type) {
    case "int":
    case "float":
      return 0;
    case "bool":
      return false;
    case "str":
      return "";
    case "none":
      return null;
    default:
      return null;
  }
}
