"use client";

/**
 * 连线视图
 * ------------------------------------------------------------------
 * 用 SVG 贝塞尔曲线绘制端口之间的连线, 类 ComfyUI 风格
 *  - 颜色 = 输出端口的类型颜色
 *  - 选中时高亮
 *  - 拖拽中的临时连线显示为虚线
 */

import { memo } from "react";
import type { WorkflowEdge } from "@/lib/pyflow/types";

interface EdgeViewProps {
  edge: WorkflowEdge;
  from: { x: number; y: number; type: string };
  to: { x: number; y: number; type?: string };
  selected: boolean;
  onSelect: () => void;
  isPending?: boolean;
}

function getTypeColor(type: string): string {
  const colors: Record<string, string> = {
    int: "#3b82f6",
    float: "#06b6d4",
    bool: "#a855f7",
    str: "#22c55e",
    bytes: "#65a30d",
    list: "#f59e0b",
    dict: "#ef4444",
    tuple: "#f97316",
    set: "#eab308",
    range: "#14b8a6",
    callable: "#ec4899",
    module: "#64748b",
    none: "#94a3b8",
    any: "#ffffff",
  };
  return colors[type] ?? "#94a3b8";
}

export const EdgeView = memo(function EdgeView({
  edge,
  from,
  to,
  selected,
  onSelect,
  isPending,
}: EdgeViewProps) {
  const color = getTypeColor(from.type);
  const dx = Math.abs(to.x - from.x);
  const cp1x = from.x + dx * 0.5;
  const cp1y = from.y;
  const cp2x = to.x - dx * 0.5;
  const cp2y = to.y;

  const path = `M ${from.x} ${from.y} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${to.x} ${to.y}`;

  // 选中状态的虚线轮廓
  const hitAreaPath = (
    <path
      d={path}
      stroke="transparent"
      strokeWidth={12}
      fill="none"
      style={{ pointerEvents: "stroke", cursor: "pointer" }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
    />
  );

  return (
    <g>
      {/* 选中时的外发光 */}
      {selected && (
        <path
          d={path}
          stroke={color}
          strokeWidth={6}
          fill="none"
          opacity={0.3}
          style={{ filter: "blur(2px)" }}
        />
      )}
      {/* 主线 */}
      <path
        d={path}
        stroke={color}
        strokeWidth={selected ? 2.5 : 2}
        fill="none"
        strokeDasharray={isPending ? "4 4" : undefined}
        opacity={isPending ? 0.7 : 1}
      />
      {/* 端点圆 */}
      <circle cx={from.x} cy={from.y} r={3} fill={color} />
      <circle cx={to.x} cy={to.y} r={3} fill={color} />
      {/* 点击热区 */}
      {!isPending && hitAreaPath}
    </g>
  );
});
