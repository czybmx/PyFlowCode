"use client";

/**
 * 节点面板 (左侧)
 * ------------------------------------------------------------------
 * 按分类列出所有可用节点, 支持:
 *  - 搜索过滤
 *  - 点击添加节点到画布中央
 *  - 拖拽到画布添加 (在 Canvas 中实现 hit-test)
 */

import { useState } from "react";
import { CATEGORY_LABELS, listByCategory } from "@/lib/pyflow/registry";
import { useWorkflowStore } from "@/store/workflow";
import type { NodeCategory } from "@/lib/pyflow/types";
import { ChevronDown, ChevronRight, Search } from "lucide-react";

const CATEGORY_ICONS: Record<NodeCategory, string> = {
  literal: "🔢",
  operator: "➕",
  comparison: "⚖️",
  logic: "🧠",
  container: "📦",
  string: "📝",
  control: "🔀",
  function: "⚙️",
  io: "🖨️",
  module: "📚",
};

export function NodePalette() {
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const addNode = useWorkflowStore((s) => s.addNode);
  const canvas = useWorkflowStore((s) => s.canvas);

  const byCategory = listByCategory();

  const toggleCategory = (cat: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const handleAdd = (type: string) => {
    // 添加到画布中央
    const x = (window.innerWidth / 2 - 320 - canvas.pan.x) / canvas.zoom - 80;
    const y = (window.innerHeight / 2 - canvas.pan.y) / canvas.zoom - 40;
    addNode(type, { x, y });
  };

  return (
    <div className="w-60 bg-[#1e1e24] border-r border-zinc-800 flex flex-col h-full">
      {/* 搜索框 */}
      <div className="p-2 border-b border-zinc-800">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="搜索节点..."
            className="w-full pl-7 pr-2 py-1.5 bg-zinc-900 border border-zinc-700 rounded text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
          />
        </div>
      </div>

      {/* 分类树 */}
      <div className="flex-1 overflow-y-auto py-1">
        {(Object.keys(byCategory) as NodeCategory[]).map((cat) => {
          const nodes = byCategory[cat].filter(
            (n) =>
              !search ||
              n.label.toLowerCase().includes(search.toLowerCase()) ||
              n.type.toLowerCase().includes(search.toLowerCase()),
          );
          if (nodes.length === 0) return null;

          const isCollapsed = collapsed.has(cat) && !search;

          return (
            <div key={cat} className="border-b border-zinc-800/50">
              <button
                className="w-full flex items-center gap-1 px-2 py-1.5 hover:bg-zinc-800/50 text-left"
                onClick={() => toggleCategory(cat)}
              >
                {isCollapsed ? (
                  <ChevronRight className="w-3 h-3 text-zinc-500" />
                ) : (
                  <ChevronDown className="w-3 h-3 text-zinc-500" />
                )}
                <span className="text-xs">{CATEGORY_ICONS[cat]}</span>
                <span className="text-xs text-zinc-300 font-medium flex-1">
                  {CATEGORY_LABELS[cat]}
                </span>
                <span className="text-[10px] text-zinc-600">{nodes.length}</span>
              </button>
              {!isCollapsed && (
                <div className="pb-1">
                  {nodes.map((node) => (
                    <button
                      key={node.type}
                      onClick={() => handleAdd(node.type)}
                      className="w-full flex items-center gap-2 px-4 py-1 hover:bg-amber-500/10 text-left group"
                    >
                      <span className="w-1 h-1 rounded-full bg-zinc-600 group-hover:bg-amber-500" />
                      <span className="text-[11px] text-zinc-400 group-hover:text-amber-300 truncate">
                        {node.label}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 底部提示 */}
      <div className="p-2 border-t border-zinc-800 text-[10px] text-zinc-600">
        点击节点添加到画布中央
      </div>
    </div>
  );
}
