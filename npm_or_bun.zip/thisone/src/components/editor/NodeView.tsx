"use client";

/**
 * 节点视图组件
 * ------------------------------------------------------------------
 * 渲染单个节点 (ComfyUI 风格):
 *  - 顶部: 节点标题 (可拖拽)
 *  - 左侧: 输入端口列表
 *  - 右侧: 输出端口列表
 *  - 中间: 节点参数 (可编辑的)
 *  - 端口圆点颜色 = Python 类型颜色
 *  - 选中时高亮边框
 *  - 子图节点显示 "双击进入" 提示
 */

import { useEffect, useRef, useState } from "react";
import { getNodeDef } from "@/lib/pyflow/registry";
import { getTypeColor, getTypeLabel } from "@/lib/pyflow/types";
import type { PyType, PyValue, WorkflowNode, PortDef } from "@/lib/pyflow/types";
import { ParamEditor } from "./ParamEditor";

interface NodeViewProps {
  node: WorkflowNode;
  selected: boolean;
  zoom: number;
  canvasPan: { x: number; y: number };
  canvasZoom: number;
  canvasRef: React.RefObject<HTMLDivElement | null>;
  onSelect: () => void;
  onDragStart: (e: React.MouseEvent) => void;
  onDoubleClick: () => void;
  onPortMouseDown: (
    e: React.MouseEvent,
    portId: string,
    direction: "input" | "output",
  ) => void;
  onPortHover: (
    portId: string,
    direction: "input" | "output",
    pos: { x: number; y: number },
    type: PyType,
  ) => void;
  onPortLeave: () => void;
  registerPortPosition: (
    nodeId: string,
    portId: string,
    pos: { x: number; y: number },
    type: PyType,
    direction: "input" | "output",
  ) => void;
}

export function NodeView({
  node,
  selected,
  zoom,
  onSelect,
  onDragStart,
  onDoubleClick,
  onPortMouseDown,
  onPortHover,
  onPortLeave,
  registerPortPosition,
  canvasPan,
  canvasZoom,
  canvasRef,
}: NodeViewProps) {
  const def = getNodeDef(node.type);
  const nodeRef = useRef<HTMLDivElement>(null);

  // 注册端口位置 (每次节点位置变化时重新计算)
  useEffect(() => {
    if (!nodeRef.current || !def) return;

    const updatePositions = () => {
      const nodeRect = nodeRef.current!.getBoundingClientRect();
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;

      // 节点在画布坐标系中的位置
      const nodeCanvasX = node.pos.x;
      const nodeCanvasY = node.pos.y;

      // 找到所有端口元素
      const portEls = nodeRef.current!.querySelectorAll("[data-port]");
      portEls.forEach((el) => {
        const portEl = el as HTMLElement;
        const portId = portEl.dataset.portId!;
        const direction = portEl.dataset.portDir as "input" | "output";
        const portType = portEl.dataset.portType as PyType;

        // 端口圆点中心相对于节点容器的位置 (CSS 像素)
        const portRect = portEl.getBoundingClientRect();
        const offsetX = (portRect.left + portRect.width / 2 - nodeRect.left) / canvasZoom;
        const offsetY = (portRect.top + portRect.height / 2 - nodeRect.top) / canvasZoom;

        // 端口在画布坐标系中的位置
        const canvasX = nodeCanvasX + offsetX;
        const canvasY = nodeCanvasY + offsetY;

        registerPortPosition(node.id, portId, { x: canvasX, y: canvasY }, portType, direction);
      });
    };

    // 延迟一帧让 DOM 完成布局
    const raf = requestAnimationFrame(updatePositions);
    return () => cancelAnimationFrame(raf);
  }, [node.pos, node.params, def, registerPortPosition, node.id, canvasRef, canvasZoom]);

  if (!def) {
    return (
      <div
        ref={nodeRef}
        data-node-id={node.id}
        className="absolute bg-red-900 border border-red-500 p-2 text-xs text-white"
        style={{ left: node.pos.x, top: node.pos.y, width: 160 }}
      >
        未知节点: {node.type}
      </div>
    );
  }

  const status = node._runtime?.status;
  const statusColor =
    status === "ok"
      ? "border-l-emerald-500"
      : status === "error"
      ? "border-l-red-500"
      : status === "running"
      ? "border-l-blue-500"
      : "border-l-zinc-600";

  return (
    <div
      ref={nodeRef}
      data-node-id={node.id}
      className={`absolute select-none rounded-md border ${
        selected ? "border-amber-400 shadow-[0_0_0_2px_rgba(251,191,36,0.4)]" : "border-zinc-700"
      } ${statusColor} border-l-4 bg-[#25252b] text-zinc-100 shadow-lg`}
      style={{
        left: node.pos.x,
        top: node.pos.y,
        width: def.defaultSize?.width ?? 180,
        minWidth: 140,
      }}
      onMouseDown={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      onDoubleClick={onDoubleClick}
    >
      {/* 节点标题 */}
      <div
        className="px-3 py-1.5 cursor-move border-b border-zinc-700 flex items-center justify-between gap-2 bg-[#2d2d35] rounded-t-md"
        onMouseDown={onDragStart}
      >
        <span className="text-xs font-medium truncate">{node.title ?? def.label}</span>
        {def.isSubgraph && (
          <span className="text-[10px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-300">
            子图
          </span>
        )}
      </div>

      {/* 端口 + 参数区 */}
      <div className="flex">
        {/* 输入端口 */}
        <div className="flex-1 py-2">
          {def.inputs.length === 0 && (
            <div className="px-3 text-[10px] text-zinc-500 italic">无输入</div>
          )}
          {def.inputs.map((port) => (
            <PortRow
              key={port.id}
              port={port}
              direction="input"
              nodeId={node.id}
              onPortMouseDown={onPortMouseDown}
              onPortHover={onPortHover}
              onPortLeave={onPortLeave}
            />
          ))}
        </div>

        {/* 输出端口 */}
        <div className="flex-1 py-2">
          {def.outputs.length === 0 && (
            <div className="px-3 text-[10px] text-zinc-500 italic text-right">无输出</div>
          )}
          {def.outputs.map((port) => (
            <PortRow
              key={port.id}
              port={port}
              direction="output"
              nodeId={node.id}
              onPortMouseDown={onPortMouseDown}
              onPortHover={onPortHover}
              onPortLeave={onPortLeave}
            />
          ))}
        </div>
      </div>

      {/* 参数编辑器 (字面量等) */}
      {def.inputs.length === 0 && def.outputs.length > 0 && (
        <div className="px-3 pb-2 border-t border-zinc-700 pt-2">
          <ParamEditor node={node} port={def.outputs[0]} />
        </div>
      )}

      {/* 子图节点的提示 */}
      {def.isSubgraph && (
        <div className="px-3 pb-2 pt-1 border-t border-zinc-700">
          <div className="text-[10px] text-amber-300/70">
            双击进入子图编辑函数体
          </div>
        </div>
      )}

      {/* 错误提示 */}
      {node._runtime?.error && (
        <div className="px-3 py-1 bg-red-950/40 border-t border-red-800 text-[10px] text-red-300">
          ⚠ {node._runtime.error}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 端口行
// ---------------------------------------------------------------------------

interface PortRowProps {
  port: PortDef;
  direction: "input" | "output";
  nodeId: string;
  onPortMouseDown: (e: React.MouseEvent, portId: string, direction: "input" | "output") => void;
  onPortHover: (
    portId: string,
    direction: "input" | "output",
    pos: { x: number; y: number },
    type: PyType,
  ) => void;
  onPortLeave: () => void;
}

function PortRow({ port, direction, nodeId, onPortMouseDown, onPortHover, onPortLeave }: PortRowProps) {
  const color = getTypeColor(port.type);
  const isInput = direction === "input";

  return (
    <div
      className={`flex items-center gap-2 px-3 py-1 text-[11px] ${isInput ? "" : "flex-row-reverse"}`}
    >
      <div
        data-port
        data-port-id={port.id}
        data-port-node-id={nodeId}
        data-port-dir={direction}
        data-port-type={port.type}
        className="w-3 h-3 rounded-full border-2 cursor-crosshair hover:scale-125 transition-transform shrink-0"
        style={{
          backgroundColor: color,
          borderColor: color,
          boxShadow: `0 0 4px ${color}`,
        }}
        onMouseDown={(e) => onPortMouseDown(e, port.id, direction)}
        onMouseEnter={(e) => {
          const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
          onPortHover(port.id, direction, { x: rect.left, y: rect.top }, port.type);
        }}
        onMouseLeave={onPortLeave}
      />
      <span className="text-zinc-400 truncate flex-1 text-center">
        {port.label}
      </span>
      <span
        className="text-[9px] text-zinc-600 px-1 rounded shrink-0"
        style={{ color }}
      >
        {getTypeLabel(port.type)}
      </span>
    </div>
  );
}
