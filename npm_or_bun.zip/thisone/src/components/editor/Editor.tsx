"use client";

/**
 * 主编辑器布局
 * ------------------------------------------------------------------
 * ┌───────────────────────────────────────────────────────┐
 * │                    工具栏 (顶部)                       │
 * ├──────────┬─────────────────────────────┬──────────────┤
 * │          │                             │              │
 * │  节点    │                             │   属性面板    │
 * │  面板    │       节点画布               │              │
 * │  (左)    │                             ├──────────────┤
 * │          │                             │              │
 * │          │                             │   控制台     │
 * │          │                             │              │
 * ├──────────┴─────────────────────────────┴──────────────┤
 * │                    状态栏 (底部)                       │
 * └───────────────────────────────────────────────────────┘
 */

import { useEffect } from "react";
import { Toolbar } from "./Toolbar";
import { NodePalette } from "./NodePalette";
import { Canvas } from "./Canvas";
import { PropertiesPanel } from "./PropertiesPanel";
import { ConsolePanel } from "./ConsolePanel";
import { useWorkflowStore } from "@/store/workflow";
import { EXAMPLES } from "./examples";

export function Editor() {
  const loadDocument = useWorkflowStore((s) => s.loadDocument);
  const consoleLog = useWorkflowStore((s) => s.consoleLog);

  // 首次加载时载入 Hello World 示例
  useEffect(() => {
    loadDocument(EXAMPLES.hello_world);
    consoleLog("info", "欢迎使用 PyFlowCode! 已载入 Hello World 示例");
    consoleLog("info", "提示: 从左侧节点面板添加节点, 拖拽端口连线, 点击\"运行\"执行");
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#1a1a1f] overflow-hidden">
      {/* 工具栏 */}
      <Toolbar />

      {/* 主体三栏 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧: 节点面板 */}
        <NodePalette />

        {/* 中间: 画布 */}
        <div className="flex-1 relative">
          <Canvas />
        </div>

        {/* 右侧: 属性 + 控制台 (上下分割) */}
        <div className="w-72 flex flex-col border-l border-zinc-800">
          <div className="flex-1 overflow-y-auto bg-[#1e1e24]">
            <PropertiesPanel />
          </div>
          <div className="h-64 border-t border-zinc-800">
            <ConsolePanel />
          </div>
        </div>
      </div>

      {/* 状态栏 */}
      <StatusBar />
    </div>
  );
}

function StatusBar() {
  const canvas = useWorkflowStore((s) => s.canvas);
  const isRunning = useWorkflowStore((s) => s.isRunning);
  const subgraphPath = useWorkflowStore((s) => s.subgraphPath);
  const nodes = useWorkflowStore((s) => s.nodes);
  const edges = useWorkflowStore((s) => s.edges);

  return (
    <div className="flex items-center justify-between px-3 py-1 bg-[#1e1e24] border-t border-zinc-800 text-[10px] text-zinc-500">
      <div className="flex items-center gap-3">
        <span className={isRunning ? "text-amber-400" : ""}>
          {isRunning ? "● 运行中" : "○ 就绪"}
        </span>
        <span>·</span>
        <span>{nodes.length} 节点</span>
        <span>{edges.length} 连线</span>
        {subgraphPath.nodeIds.length > 0 && (
          <>
            <span>·</span>
            <span className="text-amber-400">
              子图深度: {subgraphPath.nodeIds.length}
            </span>
          </>
        )}
      </div>
      <div className="flex items-center gap-3">
        <span>
          位置: ({Math.round(canvas.pan.x)}, {Math.round(canvas.pan.y)})
        </span>
        <span>缩放: {Math.round(canvas.zoom * 100)}%</span>
      </div>
    </div>
  );
}
