"use client";

/**
 * 属性面板 (右侧上半)
 * ------------------------------------------------------------------
 * 显示选中节点的:
 *  - 节点类型 + ID
 *  - 自定义标题 (可编辑)
 *  - 所有输入端口的参数 (若无连线, 可编辑默认值)
 *  - 输出端口的运行时值 (若已执行)
 *  - 删除按钮
 */

import { useWorkflowStore } from "@/store/workflow";
import { getNodeDef } from "@/lib/pyflow/registry";
import { getTypeColor, getTypeLabel } from "@/lib/pyflow/types";
import type { PyType, PyValue, PortDef } from "@/lib/pyflow/types";
import { Trash2, Info } from "lucide-react";

export function PropertiesPanel() {
  const selectedNodeId = useWorkflowStore((s) => s.selectedNodeId);
  const nodes = useWorkflowStore((s) => s.getCurrentNodes());
  const edges = useWorkflowStore((s) => s.getCurrentEdges());
  const updateNodeParam = useWorkflowStore((s) => s.updateNodeParam);
  const updateNodeTitle = useWorkflowStore((s) => s.updateNodeTitle);
  const removeNode = useWorkflowStore((s) => s.removeNode);

  const node = nodes.find((n) => n.id === selectedNodeId);

  if (!node) {
    return (
      <div className="p-3 text-xs text-zinc-500 h-full flex flex-col items-center justify-center text-center">
        <Info className="w-5 h-5 mb-2 opacity-50" />
        <div>未选中节点</div>
        <div className="mt-1 text-[10px] text-zinc-600">点击画布中的节点查看属性</div>
      </div>
    );
  }

  const def = getNodeDef(node.type);
  if (!def) {
    return <div className="p-3 text-xs text-red-400">未知节点类型: {node.type}</div>;
  }

  const hasIncomingEdge = (portId: string) =>
    edges.some((e) => e.to === node.id && e.toPort === portId);

  return (
    <div className="flex flex-col h-full">
      {/* 头部 */}
      <div className="p-3 border-b border-zinc-800">
        <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">节点</div>
        <div className="text-sm text-zinc-200 font-medium">{def.label}</div>
        <div className="text-[10px] text-zinc-600 font-mono mt-1">{node.id}</div>
      </div>

      {/* 标题编辑 */}
      <div className="p-3 border-b border-zinc-800">
        <label className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1 block">
          显示名称
        </label>
        <input
          type="text"
          value={node.title ?? ""}
          placeholder={def.label}
          onChange={(e) => updateNodeTitle(node.id, e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-100 focus:border-amber-500 focus:outline-none"
        />
      </div>

      {/* 描述 */}
      {def.description && (
        <div className="p-3 border-b border-zinc-800">
          <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">描述</div>
          <div className="text-[11px] text-zinc-400 leading-relaxed">{def.description}</div>
        </div>
      )}

      {/* 输入端口 */}
      {def.inputs.length > 0 && (
        <div className="p-3 border-b border-zinc-800">
          <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-2">输入端口</div>
          <div className="space-y-2">
            {def.inputs.map((port) => (
              <PortParamEditor
                key={port.id}
                port={port}
                value={node.params[port.id] ?? port.default}
                hasConnection={hasIncomingEdge(port.id)}
                onChange={(v) => updateNodeParam(node.id, port.id, v)}
              />
            ))}
          </div>
        </div>
      )}

      {/* 输出端口的运行时值 */}
      {def.outputs.length > 0 && node._runtime?.outputs && (
        <div className="p-3 border-b border-zinc-800">
          <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-2">运行时输出</div>
          <div className="space-y-1.5">
            {def.outputs.map((port) => {
              const value = node._runtime?.outputs?.[port.id];
              const color = getTypeColor(port.type);
              return (
                <div key={port.id} className="flex items-start gap-2 text-[11px]">
                  <span
                    className="w-2 h-2 rounded-full mt-1 shrink-0"
                    style={{ backgroundColor: color }}
                  />
                  <span className="text-zinc-400 w-16 shrink-0">{port.label}</span>
                  <span className="text-zinc-300 font-mono break-all flex-1">
                    {formatValue(value)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 子图入口 */}
      {def.isSubgraph && (
        <div className="p-3 border-b border-zinc-800">
          <button
            onClick={() => useWorkflowStore.getState().enterSubgraph(node.id)}
            className="w-full px-2 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-600/40 text-amber-300 rounded text-xs"
          >
            进入子图编辑 →
          </button>
        </div>
      )}

      {/* 删除按钮 */}
      <div className="p-3 mt-auto">
        <button
          onClick={() => removeNode(node.id)}
          className="w-full flex items-center justify-center gap-2 px-2 py-1.5 bg-red-900/30 hover:bg-red-900/50 border border-red-800/50 text-red-300 rounded text-xs"
        >
          <Trash2 className="w-3 h-3" />
          删除节点 (Delete)
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 端口参数编辑器
// ---------------------------------------------------------------------------

interface PortParamEditorProps {
  port: PortDef;
  value: PyValue;
  hasConnection: boolean;
  onChange: (v: PyValue) => void;
}

function PortParamEditor({ port, value, hasConnection, onChange }: PortParamEditorProps) {
  const color = getTypeColor(port.type);

  if (hasConnection) {
    return (
      <div className="flex items-center gap-2 text-[11px] opacity-60">
        <span
          className="w-2 h-2 rounded-full shrink-0"
          style={{ backgroundColor: color }}
        />
        <span className="text-zinc-400 w-16 shrink-0">{port.label}</span>
        <span className="text-zinc-600 italic">已连接</span>
      </div>
    );
  }

  // 未连接: 显示参数编辑器
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-2">
        <span
          className="w-2 h-2 rounded-full shrink-0"
          style={{ backgroundColor: color }}
        />
        <span className="text-zinc-400 text-[11px] flex-1">{port.label}</span>
        <span className="text-[9px] text-zinc-600 font-mono">{getTypeLabel(port.type)}</span>
      </div>
      <PortValueInput port={port} value={value} onChange={onChange} />
    </div>
  );
}

function PortValueInput({
  port,
  value,
  onChange,
}: {
  port: PortDef;
  value: PyValue;
  onChange: (v: PyValue) => void;
}) {
  if (port.type === "int") {
    return (
      <input
        type="number"
        step={1}
        value={typeof value === "number" ? value : 0}
        onChange={(e) => onChange(Math.trunc(Number(e.target.value) || 0))}
        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-[11px] text-zinc-100 focus:border-amber-500 focus:outline-none font-mono"
      />
    );
  }
  if (port.type === "float") {
    return (
      <input
        type="number"
        step={0.1}
        value={typeof value === "number" ? value : 0}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-[11px] text-zinc-100 focus:border-amber-500 focus:outline-none font-mono"
      />
    );
  }
  if (port.type === "bool") {
    return (
      <select
        value={value === true ? "true" : "false"}
        onChange={(e) => onChange(e.target.value === "true")}
        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-[11px] text-zinc-100 focus:border-amber-500 focus:outline-none"
      >
        <option value="false">False</option>
        <option value="true">True</option>
      </select>
    );
  }
  if (port.type === "str") {
    return (
      <textarea
        value={typeof value === "string" ? value : ""}
        onChange={(e) => onChange(e.target.value)}
        rows={2}
        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-[11px] text-zinc-100 focus:border-amber-500 focus:outline-none font-mono resize-none"
      />
    );
  }
  return (
    <div className="text-[10px] text-zinc-600 italic">
      此类型 ({port.type}) 无可编辑默认值
    </div>
  );
}

// ---------------------------------------------------------------------------
// 辅助
// ---------------------------------------------------------------------------

function formatValue(v: unknown): string {
  if (v === undefined) return "(未执行)";
  if (v === null) return "None";
  if (typeof v === "string") return `"${v.length > 50 ? v.slice(0, 50) + "..." : v}"`;
  if (typeof v === "number") return String(v);
  if (typeof v === "boolean") return v ? "True" : "False";
  if (Array.isArray(v)) {
    if (v.length === 0) return "[]";
    const preview = v.slice(0, 5).map(formatValue).join(", ");
    return `[${preview}${v.length > 5 ? `, ... (${v.length})` : ""}]`;
  }
  if (typeof v === "object") {
    const obj = v as { __py_type?: string; name?: string; entries?: unknown[]; items?: unknown[] };
    if (obj.__py_type === "dict") return `{${obj.entries?.length ?? 0} 项}`;
    if (obj.__py_type === "callable") return `<func ${obj.name}>`;
    if (obj.__py_type === "module") return `<module ${obj.name}>`;
    if (obj.__py_type === "range") return `range(...)`;
    if (obj.__py_type === "tuple") return `(${obj.items?.length ?? 0} 项)`;
    if (obj.__py_type === "set") return `{${obj.items?.length ?? 0} 项}`;
  }
  return String(v);
}
