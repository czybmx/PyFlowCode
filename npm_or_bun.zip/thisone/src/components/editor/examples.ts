/**
 * 示例工作流
 * ------------------------------------------------------------------
 * 预置几个示例, 帮助用户快速上手:
 *  - hello_world  : 简单的 Print + 字面量
 *  - arithmetic   : 四则运算 + 比较
 *  - list_filter  : 使用 ForEach + Filter
 *  - function_def : 定义并调用函数
 */

import type { PyFlowDocument } from "@/lib/pyflow/types";

export interface Example extends PyFlowDocument {
  name: string;
  description: string;
}

export const EXAMPLES: Record<string, Example> = {
  hello_world: {
    format_version: 1,
    name: "Hello World",
    description: "最简单的字符串打印",
    nodes: [
      {
        id: "n1",
        type: "literal_str",
        pos: { x: 80, y: 200 },
        params: { value: "Hello, PyFlowCode!" },
        _runtime: { status: "idle" },
      },
      {
        id: "n2",
        type: "io_print",
        pos: { x: 380, y: 200 },
        params: {},
        _runtime: { status: "idle" },
      },
    ],
    edges: [
      { id: "e1", from: "n1", fromPort: "value", to: "n2", toPort: "value" },
    ],
  },

  arithmetic: {
    format_version: 1,
    name: "算术运算",
    description: "5 + 3 * 2 的运算, 然后打印结果",
    nodes: [
      {
        id: "n1",
        type: "literal_int",
        pos: { x: 50, y: 100 },
        params: { value: 5 },
        _runtime: { status: "idle" },
      },
      {
        id: "n2",
        type: "literal_int",
        pos: { x: 50, y: 220 },
        params: { value: 3 },
        _runtime: { status: "idle" },
      },
      {
        id: "n3",
        type: "literal_int",
        pos: { x: 50, y: 340 },
        params: { value: 2 },
        _runtime: { status: "idle" },
      },
      {
        id: "n4",
        type: "op_mul",
        pos: { x: 280, y: 260 },
        params: {},
        _runtime: { status: "idle" },
      },
      {
        id: "n5",
        type: "op_add",
        pos: { x: 500, y: 180 },
        params: {},
        _runtime: { status: "idle" },
      },
      {
        id: "n6",
        type: "io_print",
        pos: { x: 720, y: 200 },
        params: {},
        _runtime: { status: "idle" },
      },
    ],
    edges: [
      { id: "e1", from: "n2", fromPort: "value", to: "n4", toPort: "a" },
      { id: "e2", from: "n3", fromPort: "value", to: "n4", toPort: "b" },
      { id: "e3", from: "n1", fromPort: "value", to: "n5", toPort: "a" },
      { id: "e4", from: "n4", fromPort: "result", to: "n5", toPort: "b" },
      { id: "e5", from: "n5", fromPort: "result", to: "n6", toPort: "value" },
    ],
  },

  condition: {
    format_version: 1,
    name: "条件选择",
    description: "根据年龄判断是否成年",
    nodes: [
      {
        id: "n1",
        type: "literal_int",
        pos: { x: 50, y: 100 },
        params: { value: 20 },
        _runtime: { status: "idle" },
      },
      {
        id: "n2",
        type: "literal_int",
        pos: { x: 50, y: 220 },
        params: { value: 18 },
        _runtime: { status: "idle" },
      },
      {
        id: "n3",
        type: "cmp_ge",
        pos: { x: 280, y: 160 },
        params: {},
        _runtime: { status: "idle" },
      },
      {
        id: "n4",
        type: "literal_str",
        pos: { x: 280, y: 320 },
        params: { value: "成年" },
        _runtime: { status: "idle" },
      },
      {
        id: "n5",
        type: "literal_str",
        pos: { x: 280, y: 420 },
        params: { value: "未成年" },
        _runtime: { status: "idle" },
      },
      {
        id: "n6",
        type: "control_if",
        pos: { x: 540, y: 280 },
        params: {},
        _runtime: { status: "idle" },
      },
      {
        id: "n7",
        type: "io_print",
        pos: { x: 800, y: 280 },
        params: {},
        _runtime: { status: "idle" },
      },
    ],
    edges: [
      { id: "e1", from: "n1", fromPort: "value", to: "n3", toPort: "a" },
      { id: "e2", from: "n2", fromPort: "value", to: "n3", toPort: "b" },
      { id: "e3", from: "n3", fromPort: "result", to: "n6", toPort: "condition" },
      { id: "e4", from: "n4", fromPort: "value", to: "n6", toPort: "true_value" },
      { id: "e5", from: "n5", fromPort: "value", to: "n6", toPort: "false_value" },
      { id: "e6", from: "n6", fromPort: "selected", to: "n7", toPort: "value" },
    ],
  },

  list_iterate: {
    format_version: 1,
    name: "列表遍历",
    description: "构造 range 并打印每个元素",
    nodes: [
      {
        id: "n1",
        type: "range_node",
        pos: { x: 80, y: 200 },
        params: { start: 1, stop: 6, step: 1 },
        _runtime: { status: "idle" },
      },
      {
        id: "n2",
        type: "control_for_each",
        pos: { x: 360, y: 200 },
        params: {},
        _runtime: { status: "idle" },
      },
      {
        id: "n3",
        type: "io_print",
        pos: { x: 640, y: 200 },
        params: {},
        _runtime: { status: "idle" },
      },
    ],
    edges: [
      { id: "e1", from: "n1", fromPort: "range", to: "n2", toPort: "iterable" },
      { id: "e2", from: "n2", fromPort: "items", to: "n3", toPort: "value" },
    ],
  },

  string_format: {
    format_version: 1,
    name: "字符串格式化",
    description: "用 f-string 拼接问候语",
    nodes: [
      {
        id: "n1",
        type: "literal_str",
        pos: { x: 50, y: 100 },
        params: { value: "Alice" },
        _runtime: { status: "idle" },
      },
      {
        id: "n2",
        type: "literal_int",
        pos: { x: 50, y: 240 },
        params: { value: 25 },
        _runtime: { status: "idle" },
      },
      {
        id: "n3",
        type: "str_format",
        pos: { x: 320, y: 160 },
        params: { template: "Hello, {0}! You are {1} years old." },
        _runtime: { status: "idle" },
      },
      {
        id: "n4",
        type: "io_print",
        pos: { x: 640, y: 180 },
        params: {},
        _runtime: { status: "idle" },
      },
    ],
    edges: [
      { id: "e1", from: "n1", fromPort: "value", to: "n3", toPort: "arg0" },
      { id: "e2", from: "n2", fromPort: "value", to: "n3", toPort: "arg1" },
      { id: "e3", from: "n3", fromPort: "result", to: "n4", toPort: "value" },
    ],
  },
};

export type ExampleKey = keyof typeof EXAMPLES;
